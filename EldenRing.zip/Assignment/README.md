# FIT2099 Assignment (Semester 1, 2023)
# Elden Ring

## XX_LabYYTeamZZ
Team members: Gabriel De Guzman, Zheng Rong Kang, James Chea

## Design Rationale
https://docs.google.com/document/d/1C340sTN4HTJ03vdFdGaUreezBzaTNpxSzwaAWjoTQCA/edit#