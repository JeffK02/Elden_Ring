package game.weapons;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AreaAttackAction;
import game.item.Sellable;
import game.item.Tradable;
import game.managers.shop.TradingManager;

/**
 * The AxeOfGodrick class represents the Axe of Godrick weapon item in the game. It extends the WeaponItem class
 * and implements the Sellable and Tradable interfaces.
 */
public class AxeOfGodrick extends WeaponItem implements Sellable, Tradable {

    /**
     * Constructs a new AxeOfGodrick object with default properties.
     * It sets the name, display character, damage, verb, and accuracy of the Axe of Godrick.
     * It also registers the Axe of Godrick as a tradable item with the TradingManager.
     */
    public AxeOfGodrick() {
        super("Axe Of Godrick", 'T', 142, "slashes", 84);
        TradingManager.getInstance().addTradable(this);
    }

    /**
     * Returns the selling price of the Axe of Godrick.
     *
     * @return the selling price of the Axe of Godrick
     */
    @Override
    public int sellingPrice() {
        return 100;
    }

    /**
     * Returns the trade amount required to obtain the Axe of Godrick.
     *
     * @return the trade amount required to obtain the Axe of Godrick
     */
    @Override
    public String tradeAmount() {
        return "1 Remembrance Of The Grafted";
    }

    /**
     * Performs actions when a new tick occurs at the current location with the given actor.
     * This implementation does not require any action.
     *
     * @param currentLocation the current location where the actor is located
     * @param actor           the actor holding the Axe of Godrick
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {}

    /**
     * Retrieves the skill action associated with the Axe of Godrick, targeting the given actor in the specified direction.
     * It creates a new AreaAttackAction with the target actor, direction, and the Axe of Godrick as the weapon.
     *
     * @param target    the actor to target with the skill
     * @param direction the direction in which to perform the skill
     * @return the skill action associated with the Axe of Godrick
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new AreaAttackAction(target, direction, this);
    }
}
