package game.weapons;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.ToSleepAction;
import game.actions.UnsheatheAction;
import game.item.Purchasable;
import game.item.Sellable;

/**
 * The VenomousDagger class represents the Venomous Dagger weapon item in the game.
 * It extends the WeaponItem class and implements the Sellable and Purchasable interfaces.
 */
public class VenomousDagger extends WeaponItem implements Sellable, Purchasable {

    /**
     * Constructs a new VenomousDagger object with default properties.
     * It sets the name, display character, damage, verb, and accuracy of the Venomous Dagger.
     */
    public VenomousDagger() {
        super("Venomous Dagger", ')', 130, "stabs", 90);
    }

    /**
     * Retrieves the skill action associated with the Venomous Dagger, targeting the given actor in the specified direction.
     * It creates a new ToSleepAction with the target actor, direction, and the Venomous Dagger as the weapon.
     *
     * @param target    the actor to target with the skill
     * @param direction the direction in which to perform the skill
     * @return the skill action associated with the Venomous Dagger
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new ToSleepAction(target, direction, this);
    }

    /**
     * Returns the selling price of the Venomous Dagger.
     *
     * @return the selling price of the Venomous Dagger
     */
    @Override
    public int sellingPrice() {
        return 2500;
    }

    /**
     * Returns the purchase price of the Venomous Dagger.
     *
     * @return the purchase price of the Venomous Dagger
     */
    @Override
    public int purchasePrice() {
        return 5000;
    }
}
