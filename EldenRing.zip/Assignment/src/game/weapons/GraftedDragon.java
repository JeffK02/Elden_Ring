package game.weapons;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AreaAttackAction;
import game.item.Sellable;
import game.item.Tradable;
import game.managers.shop.TradingManager;

/**
 * The GraftedDragon class represents the Grafted Dragon weapon item in the game. It extends the WeaponItem class
 * and implements the Sellable and Tradable interfaces.
 */
public class GraftedDragon extends WeaponItem implements Sellable, Tradable {

    /**
     * Constructs a new GraftedDragon object with default properties.
     * It sets the name, display character, damage, verb, and accuracy of the Grafted Dragon.
     * It also registers the Grafted Dragon as a tradable item with the TradingManager.
     */
    public GraftedDragon(){
        super("Grafted Dragon", 'N', 90, "smashes", 90);
        TradingManager.getInstance().addTradable(this);
    }

    /**
     * Returns the selling price of the Grafted Dragon.
     *
     * @return the selling price of the Grafted Dragon
     */
    @Override
    public int sellingPrice() {
        return 200;
    }

    /**
     * Returns the trade amount required to obtain the Grafted Dragon.
     *
     * @return the trade amount required to obtain the Grafted Dragon
     */
    @Override
    public String tradeAmount() {
        return "1 Remembrance Of The Grafted";
    }

    /**
     * Performs actions when a new tick occurs at the current location with the given actor.
     * This implementation does not require any action.
     *
     * @param currentLocation the current location where the actor is located
     * @param actor           the actor holding the Grafted Dragon
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {}

    /**
     * Retrieves the skill action associated with the Grafted Dragon, targeting the given actor in the specified direction.
     * It creates a new AreaAttackAction with the target actor, direction, and the Grafted Dragon as the weapon.
     *
     * @param target    the actor to target with the skill
     * @param direction the direction in which to perform the skill
     * @return the skill action associated with the Grafted Dragon
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new AreaAttackAction(target, direction, this);
    }
}
