package game.weapons;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AreaAttackAction;
import game.item.Purchasable;
import game.item.Sellable;
import game.utils.enums.AttackCapability;
import game.utils.util;

/**
 * The Grossmesser class represents a weapon item that is a grossmesser.
 *
 * It implements the Sellable and Purchasable interfaces.
 */
public class Grossmesser extends WeaponItem implements Sellable, Purchasable {

    /**
     *
     * Constructor for creating a new Grossmesser object.
     */
    public Grossmesser() {
        super("Grossmesser", '?', 115, "slashes", 85);
    }

    /**
     * Overrides the tick() method of the WeaponItem class.
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {}

    /**
     * Overrides the getSkill() method of the WeaponItem class.
     * @param target the target Actor of the action
     * @param direction the direction of the action
     * @return the Action object that is the skill of the Grossmesser
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new AreaAttackAction(target, direction, this);
    }

    /**
     *
     * Returns the selling price of the Grossmesser object.
     * @return the selling price of the Grossmesser object
     * */
    public int sellingPrice(){
        return 100;
    }
    /**
     * Returns the purchase price of the Grossmesser object.
     * @return the purchase price of the Grossmesser object
     */
    public int purchasePrice(){return 5000;}
}

