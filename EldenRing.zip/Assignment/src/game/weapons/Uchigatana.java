package game.weapons;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.UnsheatheAction;
import game.item.Purchasable;
import game.item.Sellable;

/**
 * Uchigatana is a type of WeaponItem that can be sold and purchased.
 *
 * It has a unique action called UnsheatheAction which allows the actor to unsheathe the weapon and deal damage to an enemy.
 */
public class Uchigatana extends WeaponItem implements Sellable, Purchasable {
    /**
     *
     * Constructor for creating an Uchigatana object.
     * The name, displayChar, price and verb are set as "Uchigatana", ')', 115, "slashes" respectively.
     * The damage dealt by this weapon is set as 80.
     */
    public Uchigatana() {
        super("Uchigatana", ')', 115, "slashes", 80);
    }

    /**
     * Overrides the getSkill() method of the WeaponItem class to return an UnsheatheAction object.
     * @param target The actor being targeted by the action.
     * @param direction The direction in which the action is being performed.
     * @return an UnsheatheAction object.
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new UnsheatheAction(target, direction, this);
    }
    /**
     * Overrides the tick() method of the WeaponItem class.
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    public void tick(Location currentLocation, Actor actor) {}
    /**
     *
     * Returns the selling price of the Uchigatana object.
     * @return the selling price of the Uchigatana object
     * */
    public int sellingPrice(){
        return 500;
    }
    /**
     * Returns the purchase price of the Uchigatana object.
     * @return the purchase price of the Uchigatana object
     */
    public int purchasePrice(){return 5000;};
}
