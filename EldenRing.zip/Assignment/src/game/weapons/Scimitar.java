package game.weapons;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AreaAttackAction;
/**
 * The Scimitar class represents a weapon item that is a scimitar.
 */
public class Scimitar extends WeaponItem {

    /**
     * Constructor for creating a new Scmitar object.
     *
     */
    public Scimitar() {
        super("Scimitar", 's', 118, "slashes", 88);
    }
    /**
     * Overrides the tick() method of the WeaponItem class.
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {}
    /**
     * Overrides the getSkill() method of the WeaponItem class.
     * @param target the target Actor of the action
     * @param direction the direction of the action
     * @return the Action object that is the skill of the Scimitar
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new AreaAttackAction(target, direction, this);
    }
}
