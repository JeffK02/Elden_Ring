package game.weapons;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.QuickstepAction;
import game.item.Purchasable;
import game.item.Sellable;

/**
 * The GreatKnife class represents a weapon item that is a great knife.
 *
 * It implements the Sellable and Purchasable interfaces.
 */
public class GreatKnife extends WeaponItem implements Sellable, Purchasable {

    /**
     * Constructor for creating a new GreatKnife object..
     *
     */
    public GreatKnife() {
        super("Great Knife", '/', 75, "slashes", 70);
    }

    /**
     * Overrides the tick() method of the WeaponItem class.
     * @param currentLocation the current location of the Actor
     * @param actor the Actor using the item
     */
    public void tick(Location currentLocation, Actor actor) {}

    /**
     * Overrides the getSkill() method of the WeaponItem class.
     * @param target the target Actor of the action
     * @param direction the direction of the action
     * @return the Action object that is the skill of the GreatKnife
     */
    @Override
    public Action getSkill(Actor target, String direction) {
        return new QuickstepAction(target, direction, this);
    }

    /**
     *
     * Returns the selling price of the GreatKnife object.
     * @return the selling price of the GreatKnife object
     * */
    public int sellingPrice(){
        return 350;
    }

    /**
     * Returns the purchase price of the GreatKnife object.
     * @return the purchase price of the GreatKnife object
     */
    public int purchasePrice(){return 3500;}
}
