package game.weapons;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.item.Purchasable;
import game.item.Sellable;

/**
 * A simple weapon that can be used to attack the enemy.
 * It deals 103 damage with 80% hit rate
 * Created by:
 * @author Adrian Kristanto
 * Modified by:
 *
 */
public class Club extends WeaponItem implements Sellable, Purchasable {

    /**
     * Constructor for creating a new Club object.
     */
    public Club() {
        super("Club", '!', 103, "bonks", 80);
    }

    /**
     * Overrides the tick() method of the WeaponItem class.
     * @param currentLocation the current location of the Actor
     * @param actor the Actor using the item
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {}

    /**
     * Returns the selling price of the Club object.
     * @return the selling price of the Club object
     */
    public int sellingPrice(){
        return 100;
    }

    /**
     * Returns the purchase price of the Club object.
     * @return the purchase price of the Club object
     */
    public int purchasePrice(){return 600;}
}
