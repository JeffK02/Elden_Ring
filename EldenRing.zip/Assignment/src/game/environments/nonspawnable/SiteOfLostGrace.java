package game.environments.nonspawnable;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.RestAction;
import edu.monash.fit2099.engine.positions.Ground;
import game.actors.players.Player;
import game.managers.reset.ResetManager;
import game.managers.reset.Resettable;
import game.utils.enums.GroundCapability;
import game.utils.enums.Status;

/**
 * A location that represents the site of lost grace in the Lands Between. This location
 * allows the player to rest and recover their health.
 */
public class SiteOfLostGrace extends Ground {

    /**
     * Constructor.
     */
    public SiteOfLostGrace() {
        super('U');
        addCapability(GroundCapability.SITE_OF_LOST_GRACE);
    }

    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(Status.HOSTILE_TO_ENEMY);
    }

    /**
     * Returns a list of allowable actions for the given actor at the specified location
     * and direction. If the actor is a player, a RestAction will be added to the list of
     * allowable actions.
     *
     * @param actor     the actor to return the allowable actions for
     * @param location  the location of the ground
     * @param direction the direction of the ground from the actor
     * @return a list of allowable actions
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        if (actor instanceof Player) {
            ActionList actions = new ActionList();
            actions.add(new RestAction());
            return actions;
        }
        return new ActionList();
    }
}
