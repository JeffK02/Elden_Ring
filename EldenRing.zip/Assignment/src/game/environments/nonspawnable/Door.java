package game.environments.nonspawnable;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.DoorEnterAction;

import static game.utils.enums.Status.HOSTILE_TO_ENEMY;

/**
 * A class representing the Door ground.
 * This ground will allow actors to use the Door to move to a different location
 */
public abstract class Door extends Ground {
    private Location endLocation = null;
    private String name;

    /**
     * Door constructor
     * Creates an instance of Door, preparing the display character
     * @param displayChar
     */
    public Door(char displayChar){
        super(displayChar);

    }

    /**
     * Checks if the actor can enter. Only the player can enter/stand on the door.
     * @param actor the Actor to check
     * @return boolean describing if this actor can enter
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        if (actor.hasCapability(HOSTILE_TO_ENEMY))
            return true;
        return false;
    }

    /**
     * Sets the ending location of the door
     * @param location end location of door
     */
    public void setEndLocation(Location location){
        this.endLocation = location;
    }

    /**
     * Gets the end location of the door.
     * @return Location instance of where the actor would be taken if they enter the door
     */
    public Location getEndLocation(){
        return this.endLocation;
    }

    /**
     * Sets the name of the Door.
     * @param name
     */
    public void setName(String name){
        this.name = name;
    }

    /**
     * Gets the name of the Door.
     * @return String name of door
     */
    public String getName(){
        return this.name;
    }

    /**
     * allowableActions method.
     * For Player, they can use the DoorEnterAction.
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return actionList list of allowable actions
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction){
        ActionList actionList =  new ActionList();
        if (getEndLocation() != null){
            actionList.add(new DoorEnterAction(getEndLocation(), this));
        }
        return actionList;
    }


}
