package game.environments.nonspawnable;

/**
 * GoldenFogDoor class.
 * This is a variant of door used for travel.
 */
public class GoldenFogDoor extends Door{

    /**
     * GoldenFogDoor constructor.
     * Initialises the GoldenFogDoor.
     */
    public GoldenFogDoor(){
        super('D');
        super.setName("Golden Fog Door");
    }

}
