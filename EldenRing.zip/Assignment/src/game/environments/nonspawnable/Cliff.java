package game.environments.nonspawnable;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.DeathAction;

import static game.utils.enums.Status.HOSTILE_TO_ENEMY;

/**
 * Cliff class
 * This ground will kill any actors that stand on it.
 */
public class Cliff extends Ground {

    /**
     * Cliff constructor.
     * Initialises the Cliff instance.
     */
    public Cliff(){
        super('+');
    }

    /**
     * tick method.
     * Checks if an actor is standing on it. If there is, they go poof poof.
     * @param location The location of the Ground
     */
    @Override
    public void tick(Location location) {
        if (location.containsAnActor()){
            String killByCliff = location.getActor().toString() + " walked to a cliff. "+ new DeathAction(location.getActor()).execute(location.getActor(), location.map());
            System.out.println(killByCliff);
        }
    }

    /**
     * canActorEnter method
     * Checks who can enter the Cliff. Only Player can enter.
     * @param actor the Actor to check
     * @return boolean representing if actor is valid
     */
    @Override
    public boolean canActorEnter(Actor actor){
        if (actor.hasCapability(HOSTILE_TO_ENEMY)){
            return true; // Only Player can enter the cliff
        }
        return false;
    }

}
