package game.environments.spawnable.stormveilcastle;

import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.enemies.Enemy;
import game.actors.enemies.stormveilcastle.Dog;
import game.utils.RandomNumberGenerator;
import game.utils.util;

/**
 * The Cage class represents a cage in Storm Veil Castle.
 * It extends the StormVeilCastle class and provides functionality for spawning enemies.
 */
public class Cage extends StormVeilCastle{

    /**
     * Constructor.
     */
    public Cage() {
        super('<');
    }

    /**
     * Spawn an enemy in the cage.
     *
     * @param map      the game map
     * @param location the location to spawn the enemy
     * @return the spawned enemy, or null if no enemy was spawned
     */
    @Override
    public Enemy spawnEnemy(GameMap map, Location location) {
        int prob = RandomNumberGenerator.getRandomInt(1, 100) / 100;
        if (prob <= 37) {
            Enemy newEnemy = new Dog();
            Location spawnLoc = util.FullMapSpawnLocation(map, newEnemy);
            map.addActor(newEnemy, map.at(spawnLoc.x(), spawnLoc.y()));
            return newEnemy;
        }
        return null;
    }
}
