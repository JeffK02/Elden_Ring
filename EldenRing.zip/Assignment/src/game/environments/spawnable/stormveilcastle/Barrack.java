package game.environments.spawnable.stormveilcastle;

import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.enemies.Enemy;
import game.actors.enemies.stormveilcastle.GodrickSoldier;
import game.utils.RandomNumberGenerator;
import game.utils.util;

/**
 * The Barrack class represents a barrack in Storm Veil Castle.
 * It extends the StormVeilCastle class and provides functionality for spawning enemies.
 */
public class Barrack extends StormVeilCastle{

    /**
     * Constructor.
     */
    public Barrack() {
        super('B');
    }

    /**
     * Spawn an enemy in the barrack.
     *
     * @param map      the game map
     * @param location the location to spawn the enemy
     * @return the spawned enemy, or null if no enemy was spawned
     */
    @Override
    public Enemy spawnEnemy(GameMap map, Location location) {
        int prob = RandomNumberGenerator.getRandomInt(1, 100) / 100;
        if (prob <= 45) {
            Enemy newEnemy = new GodrickSoldier();
            Location spawnLoc = util.FullMapSpawnLocation(map, newEnemy);
            map.addActor(newEnemy, map.at(spawnLoc.x(), spawnLoc.y()));
            return newEnemy;
        }
        return null;
    }
}
