package game.environments.spawnable.stormveilcastle;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.enemies.Enemy;
import game.utils.RandomNumberGenerator;
import game.utils.enums.Status;

import java.util.ArrayList;

/**
 * The StormVeilCastle class represents a location in Storm Veil Castle.
 * It extends the Ground class and provides functionality for spawning enemies.
 */
public abstract class StormVeilCastle extends Ground {
    /**
     * An ArrayList of Enemy objects currently spawned on this location.
     */
    private ArrayList<Enemy> enemies = new ArrayList<>();

    /**
     * Creates a new StormVeilCastle object with the given display character.
     * Adds the SPAWN_POINT capability for the spawn manager to check.
     *
     * @param displayChar the character used to represent this location on the game map
     */
    public StormVeilCastle(char displayChar) {
        super(displayChar);
        // For spawn manager to check
        addCapability(Status.SPAWN_POINT);
    }

    /**
     * Determines whether the given actor can enter this location.
     * In this case, only a player that is hostile to enemies can enter.
     *
     * @param actor the actor that wants to enter this location
     * @return true if the actor can enter, false otherwise
     */
    //only player can enter
    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(Status.HOSTILE_TO_ENEMY);
    }

    /**
     * Performs actions on this location when a new tick occurs.
     * Despawns enemies that are not following the player and have a despawn probability.
     * Tries to spawn a new enemy based on the spawn probability.
     *
     * @param location the location where this StormVeilCastle object exists
     */
    @Override
    public void tick(Location location) {
        GameMap map = location.map();
        despawn(map);
        Enemy newEnemy = spawnEnemy(map, location);
        if (newEnemy != null) {
            enemies.add(newEnemy);
        }
    }

    /**
     * Despawns enemies that are not following the player and have a despawn probability.
     * Removes the enemies from the game map, the list of enemies on this location, and the SpawnManager.
     *
     * @param map the game map where the enemies are located
     */
    public void despawn(GameMap map){
        ArrayList<Enemy> enemiesToRemove = new ArrayList<>();
        for (Enemy enemy : enemies) {
            int prob = RandomNumberGenerator.getRandomInt(1, 100);
            if (!enemy.hasCapability(Status.FOLLOWING) && prob <= 10) {
                enemiesToRemove.add(enemy);
            }
        }
        for (Enemy enemy : enemiesToRemove) {
            map.removeActor(enemy);
            enemies.remove(enemy);
        }
    }

    /**
     * Spawns an enemy at the specified location on the given game map.
     *
     * @param map      the game map
     * @param location the location to spawn the enemy
     * @return the spawned enemy, or null if no enemy was spawned
     */
    public abstract Enemy spawnEnemy(GameMap map, Location location);
}
