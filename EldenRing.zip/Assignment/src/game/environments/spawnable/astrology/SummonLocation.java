package game.environments.spawnable.astrology;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.SummonAction;
import game.actors.astrology.AstrologyActor;
import game.utils.enums.Status;

/**
 * The SummonLocation class represents a specific type of ground terrain where summoning can occur.
 * It extends the Ground class and provides functionality for summoning astrology actors.
 */
public abstract class SummonLocation extends Ground {

    /**
     * Constructor.
     *
     * @param displayChar character to display for this type of terrain
     */
    public SummonLocation(char displayChar) {
        super(displayChar);
    }

    /**
     * Get the allowable actions for an actor on this summon location.
     *
     * @param actor     the actor
     * @param location  the location of the summon location
     * @param direction the direction from which the actor is approaching the summon location
     * @return the list of allowable actions for the actor
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        ActionList actions = new ActionList();
        if(actor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            actions.add(new SummonAction(this));
        }
        return actions;
    }

    /**
     * Check if an actor can enter this summon location.
     *
     * @param actor the actor
     * @return true if the actor can enter, false otherwise
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(Status.HOSTILE_TO_ENEMY);
    }

    /**
     * Summon an astrology actor at this summon location.
     *
     * @return the summoned astrology actor
     */
    public abstract AstrologyActor summon();
}
