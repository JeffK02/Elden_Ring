package game.environments.spawnable.astrology;

import edu.monash.fit2099.engine.actors.Actor;
import game.actors.astrology.Ally;
import game.actors.astrology.AstrologyActor;
import game.actors.astrology.Invader;
import game.utils.RandomNumberGenerator;

/**
 * The SummonSign class represents a summoning sign on the ground.
 * It extends the SummonLocation class and provides functionality for summoning astrology actors.
 */
public class SummonSign extends SummonLocation{

    /**
     * Constructor.
     */
    public SummonSign() {
        super('=');
    }

    /**
     * Summon an astrology actor at this summon sign.
     *
     * @return the summoned astrology actor
     */
    @Override
    public AstrologyActor summon() {
        int prob = RandomNumberGenerator.getRandomInt(1,100);
        if (prob>50){
            return new Ally();
        }
        else {
            return new Invader();
        }
    }
}
