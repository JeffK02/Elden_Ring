package game.environments.spawnable;

import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.enemies.Enemy;
import game.actors.enemies.skeletal.HeavySkeletonSwordsman;
import game.actors.enemies.skeletal.SkeletalBandit;
import game.utils.RandomNumberGenerator;
import game.utils.util;


/**
 * A concrete class representing a Graveyard where enemies can spawn on the ground.
 *
 * This class is a subclass of EnemySpawningLocation and has a display character of 'n' and a spawn probability of 0.27.
 */
public class Graveyard extends EnemySpawningLocation {

    /**
     * Creates a new Graveyard object with a display character of 'n' and a spawn probability of 0.27.
     */
    public Graveyard() {
        super('n');
    }

    @Override
    public Enemy spawnWestEnemy(GameMap map, Location location) {
        if(location.x() <= Math.floorDiv(map.getXRange().max(), 2)) {
            int prob = RandomNumberGenerator.getRandomInt(1, 100) / 100;
            if (prob <= 27) {
                Enemy newEnemy = new HeavySkeletonSwordsman();
                Location spawnLoc = util.randomSpawnLocation(map, newEnemy, location);
                map.addActor(newEnemy, map.at(spawnLoc.x(), spawnLoc.y()));
                return newEnemy;
            }
        }
        return null;
    }

    @Override
    public Enemy spawnEastEnemy(GameMap map, Location location) {
        if(location.x() > Math.floorDiv(map.getXRange().max(), 2)) {
            int prob = RandomNumberGenerator.getRandomInt(1, 100);
            if (prob <= 27) {
                Enemy newEnemy = new SkeletalBandit();
                Location spawnLoc = util.randomSpawnLocation(map, newEnemy, location);
                map.addActor(newEnemy, map.at(spawnLoc.x(), spawnLoc.y()));
                return newEnemy;
            }
        }
        return null;
    }
}
