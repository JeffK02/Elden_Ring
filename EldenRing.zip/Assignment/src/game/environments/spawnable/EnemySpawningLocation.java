package game.environments.spawnable;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.enemies.Enemy;
import game.utils.RandomNumberGenerator;
import game.utils.enums.Status;

import java.util.ArrayList;

/**
 * An abstract class representing a location where enemies can spawn on the ground.
 *
 * This class is a subclass of Ground and has the capability of being a spawn point.
 *
 * It contains an ArrayList of Enemy objects that are currently spawned on this location.
 *
 * When a new tick occurs, this class will try to spawn a new enemy on this location based on the spawn probability.
 *
 * Additionally, this class can despawn enemies that are not following the player based on a despawn probability.
 */
public abstract class EnemySpawningLocation extends Ground {
    /**
     * An ArrayList of Enemy objects currently spawned on this location.
     */
    private ArrayList<Enemy> enemies = new ArrayList<>();

    /**
     *
     Creates a new EnemySpawningLocation object with the given display character and spawn probability.
     Adds the SPAWN_POINT capability for spawn manager to check.
     @param displayChar the character used to represent this location on the game map
     */
    public EnemySpawningLocation(char displayChar) {
        super(displayChar);
        // For spawn manager to check
        addCapability(Status.SPAWN_POINT);
    }

    /**
     * Determines whether the given actor can enter this location. In this case, only a player that is hostile to enemies can enter.
     * @param actor the actor that wants to enter this location
     * @return true if the actor can enter, false otherwise
     */
    //only player can enter
    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(Status.HOSTILE_TO_ENEMY);
    }

    /**
     * Performs actions on this location when a new tick occurs.
     * Despawns enemies that are not following the player and have a despawn probability.
     * Tries to spawn a new enemy based on the spawn probability.
     * @param location the location where this EnemySpawningLocation object exists
     */
    @Override
    public void tick(Location location) {
        GameMap map = location.map();
        despawn(map);
        Enemy newWestEnemy = spawnWestEnemy(map, location);
        Enemy newEastEnemy = spawnEastEnemy(map, location);
        if (newWestEnemy != null) {
            enemies.add(newWestEnemy);
        }
        if (newEastEnemy != null) {
            enemies.add(newEastEnemy);
        }
    }

    /**
     * Despawns enemies that are not following the player and have a despawn probability.
     * Removes the enemies from the game map, the list of enemies on this location, and the SpawnManager.
     * @param map the game map where the enemies are located
     */
    public void despawn(GameMap map){
        ArrayList<Enemy> enemiesToRemove = new ArrayList<>();
        for (Enemy enemy : enemies) {
            int prob = RandomNumberGenerator.getRandomInt(1, 100);
            if (!enemy.hasCapability(Status.FOLLOWING) && prob <= 10) {
                enemiesToRemove.add(enemy);
            }
        }
        for (Enemy enemy : enemiesToRemove) {
            map.removeActor(enemy);
            enemies.remove(enemy);
        }
    }

    public abstract Enemy spawnEastEnemy(GameMap map, Location location);
    public abstract Enemy spawnWestEnemy(GameMap map, Location location);
}
