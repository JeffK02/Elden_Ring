package game.environments.spawnable;

import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.enemies.Enemy;
import game.actors.enemies.crustacean.GiantCrab;
import game.actors.enemies.crustacean.GiantCrayfish;
import game.utils.RandomNumberGenerator;
import game.utils.util;

/**
 * A type of ground that has a chance of spawning an enemy when the game map is ticked. This type of ground has a medium
 * spawn probability and a specific display character.
 */
public class PuddleOfWater extends EnemySpawningLocation {

    /**
     * Constructor for a PuddleOfWater object, which sets its display character to '~', and its spawn probability to 0.2.
     */
    public PuddleOfWater() {
        super('~');
    }

    @Override
    public Enemy spawnWestEnemy(GameMap map, Location location) {
        if(location.x() <= Math.floorDiv(map.getXRange().max(), 2)) {
            int prob = RandomNumberGenerator.getRandomInt(1, 100) ;
            if (prob <= 2) {
                Enemy newEnemy = new GiantCrab();
                Location spawnLoc = util.randomSpawnLocation(map, newEnemy, location);
                map.addActor(newEnemy, map.at(spawnLoc.x(), spawnLoc.y()));
                return newEnemy;
            }
        }
        return null;
    }

    @Override
    public Enemy spawnEastEnemy(GameMap map, Location location) {
        if(location.x() > Math.floorDiv(map.getXRange().max(), 2)) {
            int prob = RandomNumberGenerator.getRandomInt(1, 100);
            if (prob <= 1) {
                Enemy newEnemy = new GiantCrayfish();
                Location spawnLoc = util.randomSpawnLocation(map, newEnemy, location);
                map.addActor(newEnemy, map.at(spawnLoc.x(), spawnLoc.y()));
                return newEnemy;
            }
        }
        return null;
    }

}
