package game.environments.spawnable;

import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.enemies.Enemy;
import game.actors.enemies.beast.GiantDog;
import game.actors.enemies.beast.LoneWolf;
import game.utils.RandomNumberGenerator;
import game.utils.util;

/**
 * A type of ground that has a chance of spawning an enemy when the game map is ticked. This type of ground has a high
 * spawn probability and a specific display character.
 */
public class GustOfWind extends EnemySpawningLocation {
    /**
     * Constructor for a GustOfWind object, which sets its display character to '&', and its spawn probability to 0.33.
     */
    public GustOfWind() {
        super('&');
    }

    @Override
    public Enemy spawnWestEnemy(GameMap map, Location location) {
        if(location.x() <= Math.floorDiv(map.getXRange().max(), 2)) {
            int prob = RandomNumberGenerator.getRandomInt(1, 100);
            if (prob <= 33) {
                Enemy newEnemy = new LoneWolf();
                Location spawnLoc = util.randomSpawnLocation(map, newEnemy, location);
                map.addActor(newEnemy, map.at(spawnLoc.x(), spawnLoc.y()));
                return newEnemy;
            }
        }
        return null;
    }

    @Override
    public Enemy spawnEastEnemy(GameMap map, Location location) {
        if(location.x() > Math.floorDiv(map.getXRange().max(), 2)) {
            int prob = RandomNumberGenerator.getRandomInt(1, 100);
            if (prob <= 4) {
                Enemy newEnemy = new GiantDog();
                Location spawnLoc = util.randomSpawnLocation(map, newEnemy, location);
                map.addActor(newEnemy, map.at(spawnLoc.x(), spawnLoc.y()));
                return newEnemy;
            }
        }
        return null;
    }
}