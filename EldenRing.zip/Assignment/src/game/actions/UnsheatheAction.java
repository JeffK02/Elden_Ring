package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.DeathAction;
import game.utils.RandomNumberGenerator;

/**
 * A class that represents an action to unsheathe a weapon and perform an attack on a target Actor in a specified direction.
 *
 * Extends the Action class.
 */
public class UnsheatheAction extends Action {
    /**
     * The target
     */
    private Actor target;
    /**
     * The direction of the target
     */
    private String direction;
    /**
     * The weapon used
     */
    private Weapon weapon;

    /**
     * Constructor for the UnsheatheAction class.
     * @param target The target Actor to perform the attack on.
     * @param direction The direction of the attack.
     * @param weapon The weapon to be unsheathed and used for the attack.
     */
    public UnsheatheAction(Actor target, String direction, Weapon weapon){
        setTarget(target);
        setDirection(direction);
        setWeapon(weapon);
    }

    /**
     * Execute the UnsheatheAction by performing an attack on the target Actor using the unsheathed weapon.
     *
     * The attack has a hit rate of 60%, and deals double the damage of the weapon.
     *
     * @param actor The Actor performing the action.
     *
     * @param map The GameMap on which the action is being performed.
     *
     * @return A String describing the result of the action.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        int doubleDamage = weapon.damage()*2;
        int hitRate = 60;

        if (RandomNumberGenerator.getRandomInt(1,100) > 60) {
            return String.format("%s fails to perform Unsheathe on %s\n", actor, target);
        }

        String result = String.format("%s performs Unsheathe on %s, dealing %d damage.\n", actor, target, doubleDamage);
        target.hurt(doubleDamage);
        if (!target.isConscious()){
            result += new DeathAction(actor).execute(target, map);
        }

        return result;
    }

    /**
     * Get the menu description of the UnsheatheAction.
     * @param actor The Actor performing the action.
     * @return A String describing the UnsheatheAction to be shown in the action menu.
     */
    @Override
    public String menuDescription(Actor actor) {
        return String.format("%s performs Unsheathe on %s at %s with %s.", actor, target, direction, weapon);
    }

    /**
     * Getter of target
     * @return the target
     */
    public Actor getTarget() {
        return target;
    }

    /**
     * setter for target
     * @param target the target
     */
    public void setTarget(Actor target) {
        this.target = target;
    }

    /**
     * Getter of direction
     * @return the direction of target
     */
    public String getDirection() {
        return direction;
    }

    /**
     * Setter for direction
     * @param direction The direction
     */
    public void setDirection(String direction) {
        this.direction = direction;
    }

    /**
     * Getter for weapon
     * @return The weapon used
     */
    public Weapon getWeapon() {
        return weapon;
    }

    /**
     * Setter for weapon
     * @param weapon The weapon used
     */
    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }
}
