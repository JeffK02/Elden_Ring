package game.actions.shoppingActions;

import edu.monash.fit2099.engine.actions.Action;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actors.players.Player;
import game.item.Sellable;



public class SellingAction extends Action {
    private Sellable soldItem;
    public SellingAction(Sellable sold){
        soldItem = sold;
    }
    @Override
    public String execute(Actor actor, GameMap map) {
        assert soldItem instanceof Item;

        if (soldItem instanceof WeaponItem) {
            actor.removeWeaponFromInventory((WeaponItem) soldItem);
        }
        if (soldItem instanceof Item) {
            actor.removeItemFromInventory((Item) soldItem);
        }
        Player.setRunes(Player.getRunes() + soldItem.sellingPrice());
        return "Selling successful. You now have: " + Player.getRunes() +" runes.";
    }

    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
