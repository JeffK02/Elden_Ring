package game.actions.shoppingActions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.shoppingActions.PurchaseAction;
import game.actions.shoppingActions.SellingAction;
import game.actors.merchants.Merchant;
import game.actors.players.Player;
import game.item.Purchasable;
import game.item.Sellable;
import game.managers.shop.PurchaseManager;
import game.managers.shop.SellingManager;
import game.managers.shop.ShoppingManager;

public class ShoppingAction extends Action {
    private Merchant merchant;

    public ShoppingAction(Merchant merchant){
        this.merchant = merchant;
    }

    public String execute(Actor actor, GameMap map){
        assert actor instanceof Player;
        int decision;
        Action action;
        ShoppingManager shoppingManager = ShoppingManager.getInstance();
        do {
            decision = shoppingManager.shoppingMenuItem();
            switch (decision) {
                case 1:
                    Purchasable purchased;
                    do{
                        purchased = null;
                        purchased = PurchaseManager.getInstance().purchaseMenu();
                        if (purchased != null ){
                            action = new PurchaseAction(purchased);
                            System.out.println(action.execute(actor, map));
                        }
                    } while (purchased != null);
                    break;
                case 2:
                    Sellable sold;
                    do{
                        sold = null;
                        sold = SellingManager.getInstance().sellingMenu(actor);
                        if (sold != null) {
                            action = new SellingAction(sold);
                            System.out.println(action.execute(actor, map));
                        }
                    } while (sold != null);
                    break;
                case 3:
                    return actor.toString() + " has finished looking at "+merchant.toString()+"'s wares.";
                default:
                    System.out.println("Invalid input.");
            }
        } while (decision != 3);
        return actor.toString() + " has finished looking at "+merchant.toString()+"'s wares.";
    }


    @Override
    public String menuDescription(Actor actor) {
        return actor.toString() + " looks through "+merchant.toString()+"'s wares.";
    }
}
