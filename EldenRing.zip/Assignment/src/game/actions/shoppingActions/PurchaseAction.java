package game.actions.shoppingActions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import edu.monash.fit2099.engine.items.Item;
import game.actors.players.Player;
import game.item.Purchasable;


public class PurchaseAction extends Action {
    private Purchasable boughtItem;
    public PurchaseAction(Purchasable item){
        boughtItem = item;
    }
    @Override
    public String execute(Actor actor, GameMap map) {
        assert boughtItem instanceof Item;

        if (boughtItem instanceof WeaponItem) {
            actor.addWeaponToInventory((WeaponItem) boughtItem);
        }
        Player.setRunes(Player.getRunes() - boughtItem.purchasePrice());
        return "Purchase successful.";
    }

    @Override
    public String menuDescription(Actor actor) {
        return null;
    }
}
