package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actors.players.Player;
import game.item.GoldenRunes;
import game.utils.RandomNumberGenerator;

/**
 * The ConsumeGoldenRuneAction class represents an action where a golden rune is consumed by an actor.
 * It increases the actor's rune count and removes the consumed golden rune from the actor's inventory.
 */
public class ConsumeGoldenRuneAction extends Action {
    private GoldenRunes goldenRunes;

    /**
     * Constructor.
     *
     * @param goldenRunes the golden rune to be consumed
     */
    public ConsumeGoldenRuneAction(GoldenRunes goldenRunes) {
        this.goldenRunes = goldenRunes;
    }

    /**
     * Executes the action of consuming a golden rune.
     *
     * @param actor the actor performing the action
     * @param map   the game map where the action is performed
     * @return a description of the action's outcome
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        int randomRunes = RandomNumberGenerator.getRandomInt(200,10000);
        Player.setRunes(Player.getRunes() + randomRunes);
        actor.removeItemFromInventory(goldenRunes);
        return String.format("%s consumed Golden Rune and gained %d runes", actor,randomRunes);
    }

    /**
     * Provides a description of the action for display in the menu.
     *
     * @param actor the actor performing the action
     * @return the menu description of the action
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " consumes Golden Rune";
    }
}
