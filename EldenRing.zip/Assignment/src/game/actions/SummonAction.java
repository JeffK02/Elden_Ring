package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.astrology.AstrologyActor;
import game.environments.spawnable.astrology.SummonLocation;
import game.utils.util;

/**
 * The SummonAction class represents an action where an actor performs a summoning action using a summon location.
 * It summons an astrology actor from the summon location and adds it to the game map.
 */
public class SummonAction extends Action {
    private SummonLocation sl;
    /**
     * Constructor.
     *
     * @param sl the summon location used for summoning
     */
    public SummonAction(SummonLocation sl){
        this.sl = sl;
    }

    /**
     * Executes the summoning action.
     * It summons an astrology actor from the summon location and adds it to the game map.
     *
     * @param actor the actor performing the action
     * @param map   the game map where the action is performed
     * @return a description of the action's outcome
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        AstrologyActor newAstrologyActor = sl.summon();
        Location summonLoc = util.FullMapSpawnLocation(map, newAstrologyActor);
        map.addActor(newAstrologyActor, map.at(summonLoc.x(), summonLoc.y()));
        return String.format("%s of %s is spawned", newAstrologyActor, newAstrologyActor.getCa());
    }

    /**
     * Provides a description of the action for display in the menu.
     *
     * @param actor the actor performing the action
     * @return the menu description of the action
     */
    @Override
    public String menuDescription(Actor actor) {
        return String.format("%s summons an Astrology Actor", actor);
    }

    /**
     * Returns the hotkey associated with the action.
     *
     * @return the hotkey
     */
    @Override
    public String hotkey() {
        return "s";
    }
}
