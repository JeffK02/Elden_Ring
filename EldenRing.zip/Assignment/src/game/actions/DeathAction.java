package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actors.enemies.skeletal.PileOfBones;
import game.actors.players.Player;
import game.managers.rune.RuneManager;
import game.runes.DeathDropRunes;
import game.managers.reset.ResetManager;
import game.runes.DropsRunes;
import game.utils.enums.EnemyAbility;
import game.utils.enums.Status;

import static game.utils.enums.ActorRuneInteraction.COLLECTS_RUNES;

/**
 * An action executed if an actor is killed.
 * Created by:
 * @author Adrian Kristanto
 * Modified by:
 *
 */
public class DeathAction extends Action {
    private Actor attacker;

    public DeathAction(Actor actor) {
        this.attacker = actor;
    }

    /**
     * When the target is killed, the items & weapons carried by target
     * will be dropped to the location in the game map where the target was
     *
     * @param target The actor performing the action.
     * @param map The map the actor is on.
     * @return result of the action to be displayed on the UI
     */
    @Override
    public String execute(Actor target, GameMap map) {
        String result = "";

        if (!(target.hasCapability(Status.HOSTILE_TO_ENEMY) && !target.hasCapability(Status.DEAD))) {
            target.addCapability(Status.DEAD);
            ActionList dropActions = new ActionList();
            // drop all items pre-reset function
            for (Item item : target.getItemInventory())
                dropActions.add(item.getDropAction(target));
            for (WeaponItem weapon : target.getWeaponInventory())
                dropActions.add(weapon.getDropAction(target));
            for (Action drop : dropActions)
                drop.execute(target, map);

            Location pob_loc = map.locationOf(target);
            // remove actor
            map.removeActor(target);
            if (target.hasCapability(EnemyAbility.PILE_OF_BONES)) {
                map.addActor(new PileOfBones(), pob_loc);
                RuneManager.getInstance().addRuneDroppingActor(new PileOfBones());
                result += menuDescription(target) + " Pile Of Bones is formed";
                return result;
            }
        }
        else {
            DeathDropRunes.removeDeathDropRunes(map);
            DeathDropRunes.createDeathDropRunes(map,target);
            ResetManager resetManager = ResetManager.getInstance();
            resetManager.resettableProcessing(map);
            resetManager.run(map);  // reset all registered resettables
            Location defaultLoc = map.at(35,10);
            if(!(map.locationOf(target).equals(Player.getTheFirstStep()))){
                map.moveActor(target, Player.getFoundSiteOfLostGrace()? Player.getTheFirstStep():defaultLoc);
            }
            return menuDescription(target) + " Player respawn at " + (Player.getFoundSiteOfLostGrace()?"The First Step":"default location");
        }

        // checking if runes need to be adjusted
        String runesGainedText = null;
        if (target instanceof DropsRunes && attacker.hasCapability(COLLECTS_RUNES)){ // if enemy drops runes and player is attacker
            // add runes value to player
            int runesGained = RuneManager.getInstance().retrieveRuneValue(target.toString());
            Player.setRunes(runesGained + Player.getRunes());
            // remove the value from the RuneManager
            RuneManager.getInstance().removeRuneDroppingActor(target.toString());
            // text saying how much runes
            if (runesGained > 0) {
                runesGainedText = "\nYou gained " + runesGained + " runes! Total runes: " + Player.getRunes();
            }
        }

        result += System.lineSeparator() + menuDescription(target);
        if (runesGainedText != null){
            result += runesGainedText;
        }

        return result;
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " is killed. (whispers... and re:zero-es it)";
    }
}
