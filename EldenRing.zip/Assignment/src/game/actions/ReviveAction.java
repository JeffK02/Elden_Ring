package game.actions;

import edu.monash.fit2099.engine.actions.Action;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.enemies.skeletal.HeavySkeletonSwordsman;

/**
 * A class that represents an Action where an Actor revives another Actor.
 * The action is executed by removing the current Actor from the map and adding the target Actor in its location.
 */
public class ReviveAction extends Action {
    /**
     * The actor to be revived
     */
    private Actor reviveTarget;

    /**
     * Constructor for the ReviveAction class.
     * @param actor the Actor performing the revive action.
     */
    public ReviveAction(Actor actor) {
        this.reviveTarget = actor;
    }

    /**
     * When this action is executed, the current Actor is removed from the map and the target Actor
     * is added in its location. The description of the action will be returned as a String.
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return the String describing the revival action that was executed.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        Location revive_loc = map.locationOf(actor);
        map.removeActor(actor);
        map.addActor(reviveTarget, revive_loc);
        return menuDescription(reviveTarget);
    }

    /**
     * Returns a String that describes the ReviveAction to be shown in the actions menu.
     * @param actor The actor performing the action.
     * @return the String that describes the ReviveAction to be shown in the actions menu.
     */
    @Override
    public String menuDescription(Actor actor) {
        return String.format("%s has revived!", reviveTarget);
    }
}
