package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.utils.RandomNumberGenerator;

/**
 * A class representing the Quickstep action, where the actor moves to an adjacent location and performs an attack.
 *
 * The actor will choose the first available exit in a clockwise manner starting from the given direction.
 */
public class QuickstepAction extends Action {
    /**
     * The target
     */
    private Actor target;
    /**
     * The weapon used to perform quickstep
     */
    private Weapon weapon;
    /**
     * The direction of the target
     */
    private String direction;

    /**
     * Constructor for QuickstepAction
     * @param actor The actor performing the quickstep action.
     * @param direction The direction of the initial attack.
     * @param weapon The weapon used for the attack.
     */
    public QuickstepAction(Actor actor, String direction, Weapon weapon){
        this.target = actor;
        this.weapon = weapon;
        this.direction = direction;
    }

    /**
     *
     * Executes the quickstep action, where the actor moves to an adjacent location and performs an attack.
     *
     * If the attack misses, no damage is dealt. If the attack hits, damage is dealt to the target actor.
     *
     * If the target actor is killed, a death action is executed. The actor then moves to the first available exit
     *
     * in a clockwise manner starting from the given direction.
     *
     * @param actor The actor performing the quickstep action.
     *
     * @param map The map the actor is on.
     *
     * @return The result of the quickstep action.
     *
     * @see DeathAction
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String result = String.format("%s performs Quickstep on %s:\n", actor, target);
        if (RandomNumberGenerator.getRandomInt(1,100) > weapon.chanceToHit()) {
            result += String.format("%s misses attack on $s while performing Quickstep\n",actor, target);
        } else{
            int damage = weapon.damage();
            result += String.format("%s %s %s for %d damage.\n", actor, weapon.verb(), target, weapon.damage());
            target.hurt(damage);
            if (!target.isConscious()){
                result += new DeathAction(actor).execute(target, map);
            }
        }
        for(Exit exit : map.locationOf(actor).getExits()){
            Location loc = exit.getDestination();
            if(!(map.isAnActorAt(loc))){
                map.moveActor(actor, loc);
                result += String.format("%s evades to %s of its original location", actor, exit.getName());
                break;
            }
        }
        return result;
    }

    /**
     * Returns a description of the quickstep action to be used in the menu UI.
     * @param actor The actor performing the quickstep action.
     * @return A string describing the quickstep action.
     */
    @Override
    public String menuDescription(Actor actor) {
        return String.format("%s performs Quickstep on %s at %s with %s.", actor, target, direction, weapon);
    }
}
