package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actors.players.Player;
import game.item.GoldenRunes;
import game.item.GoldenSeed;
import game.item.playeritems.FlaskOfCrimsonTears;
import game.utils.RandomNumberGenerator;
import game.utils.enums.ItemCapability;

/**
 * The ConsumeGoldenSeedAction class represents an action where a golden seed is consumed by an actor.
 * It upgrades the Flask of Crimson Tears in the actor's inventory by replacing it with a new upgraded flask.
 * The consumed golden seed is removed from the actor's inventory.
 */
public class ConsumeGoldenSeedAction extends Action {
    private GoldenSeed goldenSeed;

    /**
     * Constructor.
     *
     * @param goldenSeed the golden seed to be consumed
     */
    public ConsumeGoldenSeedAction(GoldenSeed goldenSeed) {
        this.goldenSeed = goldenSeed;
    }

    /**
     * Executes the action of consuming a golden seed.
     * It upgrades the Flask of Crimson Tears in the actor's inventory by replacing it with a new upgraded flask.
     *
     * @param actor the actor performing the action
     * @param map   the game map where the action is performed
     * @return a description of the action's outcome
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        FlaskOfCrimsonTears newFlask = new FlaskOfCrimsonTears();
        newFlask.upgrade();
        Item oldFlask = null;
        for(Item item:actor.getItemInventory()){
            if(item.hasCapability(ItemCapability.FLASK_OF_CRIMSON_TEARS)){
                oldFlask = item;
            }
        }
        actor.removeItemFromInventory(oldFlask);
        actor.addItemToInventory(newFlask);
        actor.removeItemFromInventory(goldenSeed);
        return String.format("%s consumed Golden Seed and upgraded Flask Of Crimson Tears", actor);
    }

    /**
     * Provides a description of the action for display in the menu.
     *
     * @param actor the actor performing the action
     * @return the menu description of the action
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " consumes Golden Seed";
    }
}
