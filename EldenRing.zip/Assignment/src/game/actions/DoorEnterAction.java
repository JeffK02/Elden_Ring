package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.environments.nonspawnable.Door;

/**
 * A class representing the action of an Actor entering a Door.
 * The actor will end up moved to a different location
 */
public class DoorEnterAction extends Action {
    private Location endLocation;
    private Door doorUsed;

    /**
     * Constructor for the DoorEnterAction class.
     * Stores the door that the actor entered, and the end destination that the door takes the actor.
     *
     * @param arrivalLocation
     * @param door
     */
    public DoorEnterAction(Location arrivalLocation, Door door){
        this.endLocation = arrivalLocation;
        this.doorUsed = door;
    }

    /**
     * getEndLocation method.
     * Used to identify the Location that the user is to be taken to.
     *
     * @return Location instane describing where the actor ends up
     */
    public Location getEndLocation(){
        return endLocation;
    }

    /**
     * execute method for DoorEnterAction.
     * Moves the actor to the described endLocation of the Door, and prints that the actor walked through a door.
     *
     * @param actor The actor performing the action.
     * @param map The map the actor is on.
     * @return String stating that actor used a door
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        map.moveActor(actor, getEndLocation());
        return actor.toString() + " walks through the " + getDoor().toString();
    }

    /**
     * Method that returns the door that was entered.
     *
     * @return Door instance that used this DoorEnterAction class
     */
    public Door getDoor(){
        return this.doorUsed;
    }

    /**
     * Describes the actor entering a door and the location they travel to
     *
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " goes through a " +  getDoor().getName();
    }
}
