package game.actions;

import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.positions.Location;
import game.managers.reset.ResetManager;
import game.managers.reset.Resettable;
import game.utils.enums.Status;

/**
 * Action for resting and waiting for a turn to pass.
 */
public class RestAction extends Action {

    @Override
    public String execute(Actor actor, GameMap map) {
        actor.addCapability(Status.RESTING);  // set the player's status to RESTING
        ResetManager resetManager = ResetManager.getInstance();
        resetManager.resettableProcessing(map);
        resetManager.run(map);  // reset all registered resettables
        return menuDescription(actor);
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " rests and recovers hit-points (and resets...)";
    }

    @Override
    public String hotkey() {
        return "r";
    }
}


