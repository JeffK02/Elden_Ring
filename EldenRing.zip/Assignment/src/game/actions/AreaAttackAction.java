package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.utils.RandomNumberGenerator;
import game.utils.enums.Status;
import game.utils.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;


/**
 *
 *This class represents an action for an Actor to perform an area attack. The area attack can be performed using
 *the Actor's intrinsic weapon or a specified weapon. When executed, the action calculates the chance to hit the
 *target list and deals damage to each target hit. The action also determines whether the target is killed.
 */
public class AreaAttackAction extends Action {
    /**
     * The direction in which the attack is being performed.
     */
    private String direction;
    /**
     * The direction in which the attack is being performed.
     */
    private Actor target;

    /**
     * Weapon used for the attack
     */
    private Weapon weapon;

    /**
     *
     * Constructor of an AreaAttackAction object with the given target and direction using the Actor's intrinsic weapon.
     * @param target the primary target of the area attack.
     * @param direction the direction in which the attack is being performed.
     *
     *
     */
    public AreaAttackAction(Actor target, String direction) {
        this.target = target;
        this.direction = direction;
    }

    /**
     * Constructor with weapon
     * Constructs an AreaAttackAction object with the given target, direction and weapon.
     * @param target the primary target of the area attack.
     * @param direction the direction in which the attack is being performed.
     * @param weapon the weapon used for the attack.
     */
    public AreaAttackAction(Actor target, String direction, WeaponItem weapon) {
        this.target = target;
        this.direction = direction;
        this.weapon = weapon;
    }

    /**
     * When executed, the chance to hit of the weapon that the Actor used is computed to determine whether
     * the actor will hit the target_list. If so, deal damage to the target_list and determine whether the target_list is killed.
     *
     * @param actor The actor performing the attack action.
     * @param map The map the actor is on.
     * @return the result of the attack, e.g. whether the target_list is killed, etc.
     * @see DeathAction
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        List<Actor> target_list = util.nearbyActor(actor, map);

        if (weapon == null) {
            weapon = actor.getIntrinsicWeapon();
        }
        String result = String.format("%s performs Area attack to %s with %s:\n", actor, target_list, weapon);


        for (Actor target : target_list){
            if (RandomNumberGenerator.getRandomInt(1,100) > weapon.chanceToHit()){
                result += String.format("%s misses %s.\n", actor, target);
            }
            else {
                int damage = weapon.damage();
                result += String.format("%s %s %s for %d damage. ", actor, weapon.verb(), target, damage);
                target.hurt(damage);
                if (!target.isConscious() && target.hasCapability(Status.HOSTILE_TO_ENEMY)) {
                    result += new DeathAction(actor).execute(target, map) + "\n";
                    return result;
                } else if (!target.isConscious()) {
                    result += new DeathAction(actor).execute(target, map) + "\n";
                }
            }
        }
        result += String.format("End of %s Area Attack.",actor);
        return result;
    }

    /**
     * Describes which target the actor is attacking with which weapon
     *
     * @param actor The actor performing the action.
     * @return a description used for the menu UI
     */
    @Override
    public String menuDescription(Actor actor) {
//        return actor + " attacks " + target_list + " at surroundings with " + (weapon != null ? weapon : "Intrinsic Weapon");
        return String.format("%s performs Area Attack on %s at %s with %s", actor, target, direction, (weapon != null ? weapon : "Intrinsic Weapon"));
    }

    public Weapon getWeapon() {
        return weapon;
    }
}

