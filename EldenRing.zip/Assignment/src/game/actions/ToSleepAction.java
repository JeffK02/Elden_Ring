package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.Weapon;
import game.utils.RandomNumberGenerator;
import game.utils.enums.Status;

/**
 * The ToSleepAction class represents an action where an actor puts a target to sleep using a specific weapon in a given direction.
 * It has a chance to successfully put the target to sleep for one round, and then performs an attack action on the target.
 */
public class ToSleepAction extends Action {
    /**
     * The target actor to put to sleep
     */
    private Actor target;
    /**
     * The direction of the target
     */
    private String direction;
    /**
     * The weapon used
     */
    private Weapon weapon;

    /**
     * Constructor.
     *
     * @param target    the target actor to put to sleep
     * @param direction the direction of the target
     * @param weapon    the weapon used for putting the target to sleep
     */
    public ToSleepAction(Actor target, String direction, Weapon weapon){
        setTarget(target);
        setDirection(direction);
        setWeapon(weapon);
    }

    /**
     * Executes the action of putting the target to sleep and performing an attack action.
     * It has a chance to successfully put the target to sleep for one round, and then performs an attack action on the target.
     *
     * @param actor the actor performing the action
     * @param map   the game map where the action is performed
     * @return a description of the action's outcome
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        String result = "";

        if (RandomNumberGenerator.getRandomInt(1,100)<=70){
            target.addCapability(Status.SLEEP);
            result += String.format("%s puts %s to sleep for one round\n", actor, target);
        }
        else {
            result += String.format("%s fails to put %s to sleep\n",actor, target);
        }

        result += new AttackAction(target, direction, weapon).execute(actor, map);

        return result;
    }

    /**
     * Provides a description of the action for display in the menu.
     *
     * @param actor the actor performing the action
     * @return the menu description of the action
     */
    @Override
    public String menuDescription(Actor actor) {
        return String.format("%s performs ToSleep on %s at %s with %s.", actor, target, direction, weapon);
    }

    /**
     * Getter of target
     * @return the target
     */
    public Actor getTarget() {
        return target;
    }

    /**
     * setter for target
     * @param target the target
     */
    public void setTarget(Actor target) {
        this.target = target;
    }

    /**
     * Getter of direction
     * @return the direction of target
     */
    public String getDirection() {
        return direction;
    }

    /**
     * Setter for direction
     * @param direction The direction
     */
    public void setDirection(String direction) {
        this.direction = direction;
    }

    /**
     * Getter for weapon
     * @return The weapon used
     */
    public Weapon getWeapon() {
        return weapon;
    }

    /**
     * Setter for weapon
     * @param weapon The weapon used
     */
    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }
}
