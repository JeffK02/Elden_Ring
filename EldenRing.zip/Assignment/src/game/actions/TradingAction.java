package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actors.merchants.Merchant;
import game.managers.shop.TradingManager;
import game.utils.enums.Status;

/**
 * The TradingAction class represents an action where an actor interacts with a merchant to perform trading.
 * It allows the actor to trade with the merchant if they are not hostile to enemies.
 */
public class TradingAction extends Action {

    /**
     * The merchant to trade with
     */
    private Merchant merchant;

    /**
     * Constructor.
     *
     * @param merchant the merchant to trade with
     */
    public TradingAction(Merchant merchant){
        this.merchant = merchant;
    }

    /**
     * Executes the action of trading with the merchant.
     * It allows the actor to trade with the merchant if they are not hostile to enemies.
     *
     * @param actor the actor performing the action
     * @param map   the game map where the action is performed
     * @return a description of the action's outcome
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (actor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            TradingManager.getInstance().trade(actor, map);
        }
        return actor.toString() + " has finished looking at "+merchant.toString()+"'s wares.";
    }

    /**
     * Provides a description of the action for display in the menu.
     *
     * @param actor the actor performing the action
     * @return the menu description of the action
     */

    @Override
    public String menuDescription(Actor actor) {
        return actor.toString() + " looks through "+merchant.toString()+"'s wares.";
    }
}
