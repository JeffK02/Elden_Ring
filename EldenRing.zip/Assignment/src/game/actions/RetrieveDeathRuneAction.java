package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actors.players.Player;
import game.managers.reset.ResetManager;
import game.runes.DeathDropRunes;
import game.utils.enums.Status;

import static game.utils.enums.ActorRuneInteraction.COLLECTS_RUNES;

public class RetrieveDeathRuneAction extends Action {
    private DeathDropRunes deathRune;

    @Override
    public String execute(Actor actor, GameMap map) {
        if (actor.hasCapability(COLLECTS_RUNES)){
            Player.setRunes(Player.getRunes() + DeathDropRunes.getRunes());
            DeathDropRunes.removeDeathDropRunes(map);
            return actor + " has recovered their runes. Total runes: " + Player.getRunes();
        } else {
            return actor + " tried to pick the runes up but does not collect runes :(";
        }
    }

    @Override
    public String menuDescription(Actor actor) {
        return "Tarnished collects their dropped runes";
    }
}
