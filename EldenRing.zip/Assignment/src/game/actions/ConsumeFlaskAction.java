package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import game.item.playeritems.FlaskOfCrimsonTears;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 * Special Action for consuming the Flask of Crimson Tears.
 * Increases actor's hitpoints by 250 points.
 */
public class ConsumeFlaskAction extends Action {
    private FlaskOfCrimsonTears flask;

    /**
     * Constructor.
     *
     * @param flask the flask to be consumed
     */
    public ConsumeFlaskAction(FlaskOfCrimsonTears flask) {
        this.flask = flask;
    }

    @Override
    public String execute(Actor actor, GameMap map) {
        return flask.consume(actor);
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " consumes " + flask;
    }

    @Override
    public String hotkey() {
        return "f";
    }
}
