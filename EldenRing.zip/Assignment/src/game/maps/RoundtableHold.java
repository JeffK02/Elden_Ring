package game.maps;

import java.util.Arrays;

/**
 * RoundtableHold class.
 * Holds the String List of RoundtableHold
 */
public class RoundtableHold extends MapContainer {

    /**
     * RoundtableHold constructor.
     * Initialises the RoundtableHold instance.
     */
    public RoundtableHold(){
        super(Arrays.asList(
                "##################",
                "#________________#",
                "#________________#",
                "#________________#",
                "#________________#",
                "#________________#",
                "#________________#",
                "#________________#",
                "#________________#",
                "#________________#",
                "########___#######"));
    }
}
