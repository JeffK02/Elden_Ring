package game.maps;

import java.util.List;

/**
 * MapContainer class.
 * Abstract class to be extended that holds the String List of different maps
 */
public abstract class MapContainer {
    private List<String> map;

    /**
     * MapContainer constructor.
     * Stores a String List map.
     * @param map the List<String> of a map/level
     */
    public MapContainer(List<String> map){
        this.map = map;
    }

    /**
     * getMap method.
     * Returns the String list of a map
     * @return String list of a map
     */
    public List<String> getMap(){
        return this.map;
    }

    /**
     * setMap method.
     * Changes the String List of map that is stored by the MapContainer
     * @param map String list of a map
     */
    public void setMap(List<String> map){
        this.map = map;
    }
}
