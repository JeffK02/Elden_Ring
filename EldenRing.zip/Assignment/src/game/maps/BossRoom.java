package game.maps;

import game.maps.MapContainer;

import java.util.Arrays;

/**
 * BossRoom class.
 * Holds the String List of the boss room
 */
public class BossRoom extends MapContainer {
    /**
     * BossRoom constructor.
     * Initialises the BossRoom instance.
     */
    public BossRoom(){
        super(Arrays.asList(
                "+++++++++++++++++++++++++",
                ".........................",
                ".........................",
                ".........................",
                ".........................",
                ".........................",
                ".........................",
                ".........................",
                "+++++++++++++++++++++++++"
        ));
    }
}
