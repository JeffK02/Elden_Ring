package game.runes;

/**
 * DropsRunes interface.
 *
 * Implemented by actors that give runes to the actors that cause their DeathAction.
 */
public interface DropsRunes {
    /**
     * Creates a valid rune value to reward the attacker (if they can collect runes)
     *
     * @return int representing runes dropped
     */
    public int generateRuneValue();
}
