package game.runes;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.RetrieveDeathRuneAction;
import game.actors.players.Player;

/**
 * An Item class that represents a Death Rune drop.
 * It has a runes amount and is created in the player's location if the player has runes in their inventory.
 * The Death Rune can be searched and removed from the game map.
 */
public class DeathDropRunes extends Item {
    private static int runesAmount = 0;

    /**
     * Constructor that initializes the Death Rune's name, display character and boolean value indicating whether it is portable or not.
     */
    public DeathDropRunes() {
        super("Death Rune", '$', false);
        addAction(new RetrieveDeathRuneAction());
    }

    /**
     * Creates a Death Rune in the player's location if the player has runes in their inventory.
     *
     * @param map   the game map
     * @param actor the actor
     */
    public static void createDeathDropRunes(GameMap map, Actor actor) {
        if (actor instanceof Player) {
            int runes = Player.getRunes();
            if (runes > 0) {
                DeathDropRunes.runesAmount = runes;
                DeathDropRunes deathRuneDrop = new DeathDropRunes();
                Player.setRunes(0);
                Player.getRuneDropLocation().addItem(deathRuneDrop);
            }
        }
    }

    /**
     * Removes the Death Rune from the game map.
     *
     * @param map the game map
     */
    public static void removeDeathDropRunes(GameMap map) {
        for (int x = 0; x < map.getXRange().max(); x++) {
            for (int y = 0; y < map.getYRange().max(); y++) {
                Location location = map.at(x, y);
                for (Item item : location.getItems()) {
                    if (item instanceof DeathDropRunes) {
                        location.removeItem(item);
                        return;
                    }
                }
            }
        }
    }

    public static int getRunes(){
        return DeathDropRunes.runesAmount;
    }
}
