package game;

import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.positions.World;
import game.actors.astrology.Invader;
import game.actors.merchants.FingerReaderEnia;
import game.actors.merchants.MerchantKale;
import game.environments.nonspawnable.Dirt;
import game.environments.nonspawnable.Floor;
import game.environments.nonspawnable.Wall;
import game.environments.spawnable.Graveyard;
import game.environments.spawnable.GustOfWind;
import game.environments.spawnable.PuddleOfWater;
import game.environments.nonspawnable.SiteOfLostGrace;
import game.environments.spawnable.astrology.SummonSign;
import game.environments.spawnable.stormveilcastle.Barrack;
import game.environments.spawnable.stormveilcastle.Cage;
import game.managers.map.MapManager;
import game.managers.menu.MenuManager;
import game.utils.FancyMessage;

/**
 * The main class to start the game.
 * Created by:
 * @author Adrian Kristanto
 * Modified by:
 *
 */
public class Application {

	public static void main(String[] args) {

		// BEHOLD, ELDEN RING
		for (String line : FancyMessage.ELDEN_RING.split("\n")) {
			new Display().println(line);
			try {
				Thread.sleep(200);
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}

		World world = new World(new Display());

		// Getting mapManager and loading the maps into world
		MapManager mapManager = MapManager.getInstance();
		mapManager.processMaps(world);

		// HINT: what does it mean to prefer composition to inheritance?
		/*MenuManager.getInstance().addNewPlayer(world, gameMap);*/ //currently in MapManager
		world.run();
	}
}
