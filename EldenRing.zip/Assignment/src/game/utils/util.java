package game.utils;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.players.*;

import java.util.ArrayList;
import java.util.List;

public class util {

    // helper method to get all the nearby actors
    public static List<Actor> nearbyActor(Actor actor, GameMap map) {
        List<Actor> actors = new ArrayList<>();
        Location here = map.locationOf(actor);
//        Location here = actor.;

        for (Exit exit : here.getExits()) {
            if (map.isAnActorAt(exit.getDestination())) {
                actors.add(map.getActorAt(exit.getDestination()));
            }
        }
        return actors;
    }

    public static String directionToActor(Actor source, Actor target, GameMap map) {
        for (Exit exit : map.locationOf(source).getExits()) {
            if (map.getActorAt(exit.getDestination()) == target) {
                return exit.getName();
            }
        }
        return null;
    }

    public static Location randomSpawnLocation(GameMap map, Actor actor, Location loc) {
        Boolean flag = false;
        Location output = null;
        int xMax = map.getXRange().max();
        int yMax = map.getYRange().max();
        int xMin = map.getXRange().min();
        int yMin = map.getYRange().min();
        int bound = Math.floorDiv(xMax, 2);

        //East
        if(loc.x()>bound){
            while (!flag) {
                int a = RandomNumberGenerator.getRandomInt(bound, xMax);
                int b = RandomNumberGenerator.getRandomInt(yMin, yMax);
                output = map.at(a, b);
                if (output.canActorEnter(actor)) {
                    flag = true;
                }
            }
        }
        //West
        else if (loc.x()<=bound) {
            while (!flag) {
                int a = RandomNumberGenerator.getRandomInt(xMin,bound);
                int b = RandomNumberGenerator.getRandomInt(yMin, yMax);
                output = map.at(a, b);
                if (output.canActorEnter(actor)) {
                    flag = true;
                }
            }
        }

        return output;
    }
    public static Location FullMapSpawnLocation(GameMap map, Actor actor) {
        Boolean flag = false;
        Location output = null;
        int xMax = map.getXRange().max();
        int yMax = map.getYRange().max();
        int xMin = map.getXRange().min();
        int yMin = map.getYRange().min();

        while (!flag) {
            int a = RandomNumberGenerator.getRandomInt(xMin, xMax);
            int b = RandomNumberGenerator.getRandomInt(yMin, yMax);
            output = map.at(a, b);
            if (output.canActorEnter(actor)) {
                flag = true;
            }
        }
        return output;
    }

    public static CombatArchetype randomCA(){
        int rand = RandomNumberGenerator.getRandomInt(1,4);
        switch (rand){
            case 1:
                return Samurai.getInstance();
            case 2:
                return Bandit.getInstance();
            case 3:
                return Wretch.getInstance();
            case 4:
                return Astrologer.getInstance();
        }
        return null;
    }
}