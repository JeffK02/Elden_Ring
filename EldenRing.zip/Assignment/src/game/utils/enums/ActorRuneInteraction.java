package game.utils.enums;

public enum ActorRuneInteraction {
    COLLECTS_RUNES
}
