package game.utils.enums;

public enum GroundCapability {
    SITE_OF_LOST_GRACE
}
