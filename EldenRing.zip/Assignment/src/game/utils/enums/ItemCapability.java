package game.utils.enums;

public enum ItemCapability {
    FLASK_OF_CRIMSON_TEARS,
    GOLDEN_RUNE,
    REMEMBRANCE_OF_THE_GRAFTED,
    GOLDEN_SEED
}
