package game.utils.enums;

public enum AttackCapability {
    AREA_ATTACK
}
