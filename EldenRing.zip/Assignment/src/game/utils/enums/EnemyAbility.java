package game.utils.enums;

public enum EnemyAbility {
    PILE_OF_BONES
}
