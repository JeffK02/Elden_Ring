package game.utils.enums;

public enum EnemyType {
    SKELETAL,
    BEAST,
    CRUSTACEAN,
    PILE_OF_BONES,
    STORM_VEIL_CASTLE
}
