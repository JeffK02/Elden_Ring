package game.utils.enums;

public enum ActorCapability {
    ALLY,
    INVADER
}
