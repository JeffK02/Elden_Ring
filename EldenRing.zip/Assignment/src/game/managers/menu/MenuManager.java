package game.managers.menu;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.World;
import game.actors.players.*;
import game.utils.RandomNumberGenerator;

import java.util.Scanner;

/**
 * The MenuManager class provides methods to allow the user to select a combat archetype from a menu and create a new player object
 * based on the selected archetype.
 */
public class MenuManager {
    private static MenuManager onlyManager = null;

    /**
     * Constructs a new MenuManager object.
     */
    private MenuManager() {
    }

    /**
     * Returns the instance of the MenuManager class. If the instance has not been created, a new one will be created.
     * @return the instance of the MenuManager class.
     */
    public static MenuManager getInstance() {
        MenuManager employee = new MenuManager();
        if (onlyManager == null) {
            onlyManager = employee;
        }
        return onlyManager;
    }

    /**
     * Displays a menu for the user to select a combat archetype.
     *
     * @return the integer value of the selected combat archetype.
     */
    public int menuItem() {
        Scanner sel = new Scanner(System.in);

        System.out.println("Please select a combat archetype.");
        System.out.println("Class 1: Samurai");
        System.out.println("Class 2: Bandit");
        System.out.println("Class 3: Wretch");
        System.out.println("Class 4: Astrologer");
        System.out.print("Select one: ");

        while (!sel.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            sel.nextLine(); // consume the invalid input
        }

        int choice = sel.nextInt();
        System.out.println("Your choice: Class " + choice + "\n");
        return choice;
    }

    /**
     *
     * Creates a new player object based on the user's selected combat archetype.
     * @return the new player object.
     */
    public Player classSelection() {
        Player player = null;
        int choice;
        do {
            choice = menuItem();
            switch (choice) {
                case 1:
                    player = new Player(Samurai.getInstance());
                    System.out.println("You have chosen SAMURAI");
                    break;
                case 2:
                    player = new Player(Bandit.getInstance());
                    System.out.println("You have chosen BANDIT");
                    break;
                case 3:
                    player = new Player(Wretch.getInstance());
                    System.out.println("You have chosen WRETCH");
                    break;
                case 4:
                    player = new Player(Astrologer.getInstance());
                    System.out.println("You have chosen ASTROLOGER");
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        } while (!(choice>0 && choice <= 4));
        return player;
    }

    /**
     * Adds a new player object to the specified game map at the specified location.
     * @param world the game world.
     * @param map the game map.
     */
    public void addNewPlayer(World world, GameMap map){
        Player newPlayer = classSelection();
        world.addPlayer(newPlayer, map.at(35, 10));
    }

}
