package game.managers.rune;

import game.actors.players.Player;
import game.runes.DropsRunes;

import java.util.ArrayList;
import java.util.HashMap;

public class RuneManager {
    private int playerRunes;
    private HashMap<String, ArrayList<Integer>> runeDropValues = new HashMap<String, ArrayList<Integer>>();
    private static RuneManager onlyManager = null;
    private RuneManager(){}
    public static RuneManager getInstance(){
        if (onlyManager == null){
            RuneManager runeManager = new RuneManager();
            runeManager.playerRunes = Player.getRunes();
            onlyManager = runeManager;
        }
        return onlyManager;
    }

    public void addRuneDroppingActor(DropsRunes runeDropActor){
        if (runeDropValues.containsKey(runeDropActor.toString())){
            ArrayList<Integer> tempList = runeDropValues.get(runeDropActor.toString());
            tempList.add(runeDropActor.generateRuneValue());
        }
        else {
            ArrayList<Integer> tempList = new ArrayList<Integer>();
            tempList.add(runeDropActor.generateRuneValue());
            runeDropValues.put(runeDropActor.toString(), tempList);
        }
    }

    public int retrieveRuneValue(String nameOfActor){
        return runeDropValues.get(nameOfActor).get(0);
    }

    public void removeRuneDroppingActor(String nameOfActor){
        ArrayList<Integer> tempList = runeDropValues.get(nameOfActor);
        if (tempList.size() < 2){
            runeDropValues.remove(nameOfActor);
        }
        else {
            tempList.remove(0);
            runeDropValues.put(nameOfActor, tempList);
        }
    }
}
