package game.managers.shop;

import java.util.Scanner;

public class ShoppingManager {

    private static ShoppingManager shoppingManager = null;

    private ShoppingManager(){};

    public static ShoppingManager getInstance(){
        if (shoppingManager == null) {
            shoppingManager = new ShoppingManager();
        }
        return shoppingManager;
    }

    public int shoppingMenuItem(){
        Scanner sel = new Scanner(System.in);
        System.out.println("Choose an Action:");
        System.out.println("1) Buy weapons");
        System.out.println("2) Sell weapons or items");
        System.out.println("3) Exit");
        while (!sel.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            sel.nextLine(); // consume the invalid input
        }

        int choice = sel.nextInt();
        System.out.println("Your choice: " + choice + "\n");
        return choice;
    }
}
