package game.managers.shop;

import game.actors.merchants.Merchant;
import game.actors.merchants.MerchantKale;
import game.actors.players.Player;
import game.item.Purchasable;
import java.util.ArrayList;
import java.util.Scanner;

public class PurchaseManager {
    private static PurchaseManager purchaseManager = null;

    private PurchaseManager(){};

    public static PurchaseManager getInstance(){
        if (purchaseManager == null){
            purchaseManager = new PurchaseManager();
        }
        return purchaseManager;
    }

    public Purchasable purchaseMenu(){
        Scanner sel = new Scanner(System.in);
        int choice;
        ArrayList<Purchasable> weaponOfferings = MerchantKale.listWares();
        do {
            for (int i = 0; i < weaponOfferings.size(); i++){
                System.out.println(String.valueOf(i+1) + ") " + weaponOfferings.get(i).toString() + ", " + weaponOfferings.get(i).purchasePrice());
            }
            System.out.println("0) Exit");
            System.out.println("Choose an option: ");

            while (!sel.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                sel.nextLine(); // consume the invalid input
            }
            choice = sel.nextInt();

            if (choice == 0){
                return null;
            }
            if (Player.getRunes() - weaponOfferings.get(choice-1).purchasePrice() < 0 ){
                System.out.println("Purchase failed. You have: " + String.valueOf(Player.getRunes()) + " runes. Required runes: "+ String.valueOf(weaponOfferings.get(choice-1).purchasePrice()));
            } else if (choice <= weaponOfferings.size() && choice > 0){
                return weaponOfferings.get(choice-1);
            } else {
                System.out.println("Invalid selection.");
            }
        } while (true);
    }
}
