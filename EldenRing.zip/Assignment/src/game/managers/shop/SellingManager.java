package game.managers.shop;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.item.Sellable;
import game.utils.enums.ItemCapability;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class SellingManager {
    private static SellingManager sellingManager = null;

    private SellingManager(){};

    public static SellingManager getInstance() {
        if (sellingManager == null) {
            sellingManager = new SellingManager();
        }
        return sellingManager;
    }

    public Sellable sellingMenu(Actor actor){
        List<WeaponItem> weaponsList = actor.getWeaponInventory();
        ArrayList<Sellable> sellableList = new ArrayList<Sellable>();
        for (WeaponItem weapon:actor.getWeaponInventory()){
            sellableList.add((Sellable) weapon);
        }
        for (Item item: actor.getItemInventory()){
            if (item.hasCapability(ItemCapability.REMEMBRANCE_OF_THE_GRAFTED)){
                sellableList.add((Sellable) item);
            }
        }
        Scanner sel = new Scanner(System.in);
        int choice;
        do{
            for (int i = 0; i < sellableList.size(); i++){
                System.out.println(String.valueOf(i+1) + ") "+ sellableList.get(i).toString() + ", "+String.valueOf(sellableList.get(i).sellingPrice()) + " runes");
            }
            System.out.println("0) Exit");
            System.out.println("Enter your choice: ");
            while (!sel.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                sel.nextLine(); // consume the invalid input
            }
            choice = sel.nextInt();
            if (choice == 0){
                return null;
            } else if (choice > 0 && choice <= sellableList.size()) {
                return sellableList.get(choice-1);
            } else {
                System.out.println("Invalid input");
            }
        } while (true);

    }
}
