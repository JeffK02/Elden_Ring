package game.managers.shop;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.shoppingActions.SellingAction;
import game.actors.merchants.FingerReaderEnia;
import game.item.Sellable;
import game.item.Tradable;
import game.utils.enums.ItemCapability;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/**
 * The TradingManager class manages the trading actions between actors in the game.
 */
public class TradingManager {

    private HashMap<Tradable,String> tradables = new HashMap<>();
    private static TradingManager tradingManager = null;

    /**
     * Private constructor for the TradingManager class.
     */
    private TradingManager() {
    }

    /**
     * Returns the instance of the TradingManager class.
     * If the instance doesn't exist, creates a new one.
     *
     * @return the TradingManager instance
     */
    public static TradingManager getInstance() {
        if (tradingManager == null) {
            tradingManager = new TradingManager();
        }
        return tradingManager;
    }

    /**
     * Displays the trading menu and prompts the user to choose an action.
     *
     * @return the user's choice as an integer
     */
    public int tradingMenuItem() {
        Scanner sel = new Scanner(System.in);
        System.out.println("Choose an Action:");
        System.out.println("1) Trade for weapons");
        System.out.println("2) Sell weapons or items");
        System.out.println("3) Exit");
        while (!sel.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            sel.nextLine(); // consume the invalid input
        }

        int choice = sel.nextInt();
        System.out.println("Your choice: " + choice + "\n");
        return choice;
    }

    /**
     * Performs the trading action between the actor and the game map.
     *
     * @param actor the actor performing the trade
     * @param map   the game map
     */
    public void trade(Actor actor, GameMap map) {
        int choice;
        Action action;
        do {
            choice = tradingMenuItem();
            switch (choice) {
                case 1:
                    WeaponItem traded = trading(actor);
                    if(traded != null){
                        actor.addWeaponToInventory(traded);
                        System.out.println("Traded Remembrance Of The Grafted for " + traded);
                        Item used = null;
                        for (Item item:actor.getItemInventory() ){
                            if(item.hasCapability(ItemCapability.REMEMBRANCE_OF_THE_GRAFTED)){
                               used = item;
                            }
                        }
                        actor.removeItemFromInventory(used);
                    }
                    break;
                case 2:
                    Sellable sold;
                    do{
                        sold = null;
                        sold = SellingManager.getInstance().sellingMenu(actor);
                        if (sold != null) {
                            action = new SellingAction(sold);
                            System.out.println(action.execute(actor, map));
                        }
                    } while (sold != null);
                    break;
                case 3:
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        } while (choice != 3);
    }

    /**
     * Performs the trading action between the actor and returns the traded weapon item.
     *
     * @param actor the actor performing the trade
     * @return the traded weapon item, or null if the trade is unsuccessful
     */
    public WeaponItem trading(Actor actor) {
        Scanner sel = new Scanner(System.in);
        int choice;
        ArrayList<WeaponItem> tradableWeapons = FingerReaderEnia.listWares();
        do {
            for (int i = 0; i < tradableWeapons.size(); i++) {
                System.out.println(String.valueOf(i + 1) + ") " + tradableWeapons.get(i).toString() + ", " + tradables.get(tradableWeapons.get(i)));
            }
            System.out.println("0) Exit");
            System.out.println("Choose an option: ");

            while (!sel.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                sel.nextLine(); // consume the invalid input
            }
            choice = sel.nextInt();

            if (choice == 0) {
                return null;
            } else if (choice > 0 && choice <= tradableWeapons.size()) {
                for (Item item:actor.getItemInventory() ){
                    if(item.hasCapability(ItemCapability.REMEMBRANCE_OF_THE_GRAFTED)){
                        return tradableWeapons.get(choice-1);
                    }
                }
                System.out.println("Trade Failed! You do not have enough Remembrance Of The Grafted");
            } else {
                System.out.println("Invalid selection.");
            }
        } while (true);
    }

    /**
     * Adds a tradable item to the tradables collection.
     *
     * @param t the tradable item
     */
    public void addTradable(Tradable t){
        tradables.put(t, t.tradeAmount());
    }
}
