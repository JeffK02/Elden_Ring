package game.managers.map;

import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.positions.World;
import game.actors.astrology.Ally;
import game.actors.astrology.Invader;
import game.actors.merchants.FingerReaderEnia;
import game.actors.merchants.MerchantKale;
import game.environments.nonspawnable.*;
import game.environments.spawnable.Graveyard;
import game.environments.spawnable.GustOfWind;
import game.environments.spawnable.PuddleOfWater;
import game.environments.spawnable.astrology.SummonSign;
import game.environments.spawnable.stormveilcastle.Barrack;
import game.environments.spawnable.stormveilcastle.Cage;
import game.managers.menu.MenuManager;
import game.maps.BossRoom;
import game.maps.Limgrave;
import game.maps.RoundtableHold;
import game.maps.StormveilCastle;

/**
 * MapManager class.
 * This class is responsible for the managing of all of the world's gameMaps.
 */
public class MapManager {
    private static MapManager onlyInstance = null;
    private FancyGroundFactory groundFactory;

    private MapManager(){
    }

    /**
     * MapManager getInstance method
     * @return MapManager class
     */
    public static MapManager getInstance(){
        if (onlyInstance == null){
            onlyInstance = new MapManager();
        }
        return onlyInstance;
    }

    /**
     * processMaps method.
     * Must be used to process all of the maps for the game.
     * Only to be used by Application.
     * @param world the world instance that the maps will be processed to
     */
    public void processMaps(World world){
        // Loading grounds
        groundFactory = new FancyGroundFactory(new Dirt(), new Wall(), new Floor(), new Graveyard(), new GustOfWind(), new PuddleOfWater(), new SiteOfLostGrace(), new Barrack(), new Cage(), new Cliff(), new SummonSign());

        // Creating GameMap maps
        GameMap limgrave = new GameMap(groundFactory, new Limgrave().getMap());
        GameMap stormveilCastle = new GameMap(groundFactory, new StormveilCastle().getMap());
        GameMap bossRoom = new GameMap(groundFactory, new BossRoom().getMap());
        GameMap roundtableHold = new GameMap(groundFactory, new RoundtableHold().getMap());

        // Storing GameMap into world
        world.addGameMap(limgrave);
        world.addGameMap(stormveilCastle);
        world.addGameMap(bossRoom);
        world.addGameMap(roundtableHold);

        // Add relevant tiles and actors
        // actors
        limgrave.at(38,12).addActor(new MerchantKale());
        limgrave.at(38,10).addActor(new FingerReaderEnia());

        // tiles
        // Limgrave to RoundtableHold
        GoldenFogDoor limgraveToRoundtableHold = new GoldenFogDoor();
        limgraveToRoundtableHold.setEndLocation(roundtableHold.at(9, 10));
        limgrave.at(0, 0).setGround(limgraveToRoundtableHold); // topleft

        // Limgrave to StormveilCastle
        GoldenFogDoor limgraveToStormveilCastle = new GoldenFogDoor();
        limgraveToStormveilCastle.setEndLocation(stormveilCastle.at(38, 23));
        limgrave.at(33, 9).setGround(limgraveToStormveilCastle);

        // StormveilCastle to Limgrave
        GoldenFogDoor stormveilCastleToLimgrave = new GoldenFogDoor();
        stormveilCastleToLimgrave.setEndLocation(limgrave.at(74, 23));
        stormveilCastle.at(38, 23).setGround(stormveilCastleToLimgrave); // middle bottom stormveil

        // StormveilCastle to Boss
        GoldenFogDoor stormveilCastleToBossRoom = new GoldenFogDoor();
        stormveilCastleToBossRoom.setEndLocation(bossRoom.at(13, 7));
        stormveilCastle.at(36, 11).setGround(stormveilCastleToBossRoom); // middle

        // RoundtableHold to Limgrave
        GoldenFogDoor roundtableHoldToLimgrave = new GoldenFogDoor();
        roundtableHoldToLimgrave.setEndLocation(limgrave.at(0,0));
        roundtableHold.at(9, 10).setGround(roundtableHoldToLimgrave); //bottom middle roundtable

        // Adding player
        MenuManager.getInstance().addNewPlayer(world, limgrave);
    }
}
