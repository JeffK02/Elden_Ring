package game.managers.reset;

import java.util.ArrayList;
import java.util.List;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.actors.Actor;
import game.actors.enemies.Enemy;

/**
 * A reset manager class that manages a list of resettables.
 * Created by: Adrian Kristanto
 * Modified by: [Your name here]
 */
public class ResetManager {
    private static List<Resettable> resettables;
    public static ResetManager instance;

    /**
     * Private constructor to enforce singleton pattern.
     */
    private ResetManager() {
        this.resettables = new ArrayList<>();
    }

    /**
     * Get the singleton instance of the reset manager.
     *
     * @return the ResetManager instance
     */
    public static ResetManager getInstance() {
        if (instance == null) {
            instance = new ResetManager();
        }
        return instance;
    }

    public static void resettableProcessing(GameMap gameMap) {
        for (int x = 0; x < gameMap.getXRange().max(); x++) {
            for (int y = 0; y < gameMap.getYRange().max(); y++) {
                Location location = gameMap.at(x, y);
                if (location.containsAnActor()) {
                    Actor actor = location.getActor();
                    if (actor instanceof Resettable) {
                        Resettable resettable = (Resettable) actor;
                        ResetManager.getInstance().registerResettable(resettable);
                    }
                }
            }
        }
    }

    /**
     * Register a Resettable with the reset manager.
     *
     * @param resettable the Resettable to register
     */
    public static void registerResettable(Resettable resettable) {
        resettables.add(resettable);
    }

    /**
     * Remove a Resettable from the reset manager.
     *
     * @param resettable the Resettable to remove
     */
    public void removeResettable(Resettable resettable) {
        resettables.remove(resettable);
    }

    /**
     * Reset the game by calling the reset method of each registered Resettable.
     */
    public static void run(GameMap gameMap) {
        for (Resettable resettable : resettables) {
            resettable.reset(gameMap);
        }
    }
}
