package game.item;

import edu.monash.fit2099.engine.items.Item;
import game.actions.ConsumeFlaskAction;
import game.actions.ConsumeGoldenRuneAction;
import game.utils.enums.ItemCapability;

/**
 * The GoldenRunes class represents an item called "Golden Runes".
 * It extends the Item class and adds the capability of a golden rune.
 * It also provides a constructor to initialize the golden runes item.
 */
public class GoldenRunes extends Item {

    /**
     * Constructor for creating a GoldenRunes object.
     * It sets the name to "Golden Runes", the display character to '*',
     * and enables the item to be portable.
     * It also adds a consume action for the golden runes and the golden rune capability.
     */
    public GoldenRunes() {
        super("Golden Runes", '*', true);
        addAction(new ConsumeGoldenRuneAction(this));
        addCapability(ItemCapability.GOLDEN_RUNE);
    }
}
