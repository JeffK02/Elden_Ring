package game.item;

/**
 * The Tradable interface represents an item that can be traded.
 * It defines a method to retrieve the trade amount of the item.
 */
public interface Tradable {

    /**
     * Retrieves the trade amount of the item.
     *
     * @return the trade amount of the item
     */
    public String tradeAmount();
}
