package game.item;

import edu.monash.fit2099.engine.items.Item;
import game.utils.enums.ItemCapability;

/**
 * RemembranceOfTheGrafted class.
 *
 * Represents an item that can be traded.
 */
public class RemembranceOfTheGrafted extends Item implements Sellable{

    /***
     * Constructor.
     */
    public RemembranceOfTheGrafted() {
        super("RemembranceOfTheGrafted", 'O', true);
        addCapability(ItemCapability.REMEMBRANCE_OF_THE_GRAFTED);
    }

    @Override
    public int sellingPrice() {
        return 20000;
    }
}
