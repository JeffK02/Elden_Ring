package game.item.playeritems;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.actions.ConsumeFlaskAction;
import game.utils.enums.ItemCapability;

/**
 * Class representing the Flask of Crimson Tears item, which can be consumed by the player
 * to restore their hit-points.
 */
public class FlaskOfCrimsonTears extends Item {

    private int usesLeft = 2;  // the number of times the Flask can be used

    public FlaskOfCrimsonTears() {
        super("Flask of Crimson Tears", 'f', false);
        addAction(new ConsumeFlaskAction(this));
        addCapability(ItemCapability.FLASK_OF_CRIMSON_TEARS);
    }

    /**
     * Method to consume the Flask of Crimson Tears item.
     * When consumed, the player's hit-points will be restored by 250 points, and the number of uses
     * remaining on the Flask will be decremented.
     * @param actor the actor that will consume the item
     * @return a string describing the result of consuming the item
     */
    public String consume(Actor actor) {
        if (usesLeft > 0) {
            actor.heal(250);
            usesLeft--;
            return "Consumed Flask of Crimson Tears and restored 250 hit-points. " + usesLeft + " uses remaining.";
        } else {
            return "Flask of Crimson Tears has no uses remaining.";
        }
    }


    /**
     * Returns an action that allows an Actor to drop an item.
     *
     * @param actor the Actor that will drop the Item
     * @return a new DropItemAction that drops this Item
     */

    /**
     * Override the toString method to display the number of uses remaining on the Flask of Crimson Tears.
     * @return a string representing the Flask of Crimson Tears
     */
    @Override
    public String toString() {
        return super.toString() + " (" + usesLeft + " uses left)";
    }

    public void upgrade(){
        this.usesLeft = 4;
    }
}
