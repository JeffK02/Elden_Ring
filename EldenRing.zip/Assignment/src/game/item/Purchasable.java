package game.item;

/**
 * The Purchasable interface represents an item that can be purchased.
 * It defines a method to retrieve the purchase price of the item.
 */
public interface Purchasable {

    /**
     * Retrieves the purchase price of the item.
     *
     * @return the purchase price of the item
     */
    public int purchasePrice();
}
