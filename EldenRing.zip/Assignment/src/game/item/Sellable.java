package game.item;

/**
 * Sellable interface represents an item that can be sold.
 * Defines a method representing how much an item can be sold for.
 */
public interface Sellable {
    /**
     * Retrieve the sell price of the item.
     *
     * @return int selling price of item.
     */
    public int sellingPrice();
}
