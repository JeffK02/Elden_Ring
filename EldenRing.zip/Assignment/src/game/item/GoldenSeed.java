package game.item;

import edu.monash.fit2099.engine.items.Item;
import game.actions.ConsumeGoldenRuneAction;
import game.actions.ConsumeGoldenSeedAction;
import game.utils.enums.ItemCapability;

/**
 * The GoldenSeed class represents an item called "Golden Seed".
 * It extends the Item class and adds the capability of a golden seed.
 * It also provides a constructor to initialize the golden seed item.
 */
public class GoldenSeed extends Item {

    /**
     * Constructor for creating a GoldenSeed object.
     * It sets the name to "Golden Seed", the display character to '`',
     * and enables the item to be portable.
     * It also adds a consume action for the golden seed and the golden seed capability.
     */
    public GoldenSeed() {
        super("Golden Seed", '`', true);
        addAction(new ConsumeGoldenSeedAction(this));
        addCapability(ItemCapability.GOLDEN_SEED);
    }
}
