package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AreaAttackAction;
import game.actions.AttackAction;
import game.utils.RandomNumberGenerator;
import game.utils.enums.AttackCapability;
import game.utils.enums.EnemyType;
import game.utils.util;

import java.util.Random;

/**
 * The AttackBehaviour class represents the behaviour of attacking a target Actor.
 */
public class AttackBehaviour implements Behaviour {
    private final Actor target;
    private Random rand = new Random();

    /**
     * Constructor for AttackBehaviour class.
     * @param target the Actor target to attack.
     */
    public AttackBehaviour(Actor target){
        this.target = target;
    }

    /**
     * Returns the action to attack the target Actor based on the situation of the current Actor and the GameMap.
     *
     * @param actor the current Actor performing the attack.
     *
     * @param map the GameMap where the Actor and target are located.
     *
     * @return the Action to perform the attack on the target Actor.
     */
    //only attack player if they are 1 or 2 steps away from enemy in terms of cardinal distance
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Action final_action = null;

        //If direction not null then means target is at surrounding
        String direction = util.directionToActor(actor, target, map);

        //If target or actor not exist return null
        if (!map.contains(target) || !map.contains(actor)){
            return final_action;
        }

        //If direction is not null which means target at surrounding
        if (direction != null) {
            //special skill or special attacks
            if (RandomNumberGenerator.getRandomInt(1,100) > 50) {
                //For enemy that carries a weapon
                if (actor.getWeaponInventory().size() > 0) {
                    WeaponItem currentWeapon = actor.getWeaponInventory().get(0);
                    if (currentWeapon.getSkill(actor) != null) {
                        final_action = currentWeapon.getSkill(actor);
                    } else if (currentWeapon.getSkill(target, direction).getClass() != DoNothingAction.class) {
                        final_action = currentWeapon.getSkill(target, direction);
                    }
                    //If can perform special skill but the weapon does not have skill or special attack
                    else {
                        final_action = new AttackAction(target, direction, currentWeapon);
                    }
                }
                //For enemy type that has Area Attack as special skills
                else if (actor.hasCapability(AttackCapability.AREA_ATTACK)) {
                    final_action = new AreaAttackAction(target, direction);
                }
                //No special skill and weapon
                else {
                    final_action = new AttackAction(target, direction);
                }
            }
            //If probs < 50 so cant use skill
            else {
                //If got weapon
                if (actor.getWeaponInventory().size() > 0) {
                    final_action = new AttackAction(target, direction, actor.getWeaponInventory().get(0));
                } else {
                    //If no weapon
                    final_action = new AttackAction(target, direction);
                }
            }
        }

//        If only one actor around change area attack to single targeted
        if(util.nearbyActor(actor, map).size() == 1
                && final_action != null &&
                final_action.getClass().equals(AreaAttackAction.class)){
            if (actor.getWeaponInventory().size() > 0) {
                final_action = new AttackAction(target, direction, actor.getWeaponInventory().get(0));
            } else {
                //If no weapon
                final_action = new AttackAction(target, direction);
            }
        }
        return final_action;
    }
}
