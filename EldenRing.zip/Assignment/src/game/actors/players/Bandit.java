package game.actors.players;

import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.weapons.GreatKnife;

/**
 * The class Bandit is a subclass of CombatArchetype representing the Bandit archetype in the game.
 */
public class Bandit extends CombatArchetype{

    private static Bandit onlyBandit = null;

    /**
     * Returns the singleton instance of the Bandit archetype.
     * @return the singleton instance of the Bandit archetype.
     */
    public static Bandit getInstance(){
        Bandit bandit = new Bandit(414, new GreatKnife());
        if (onlyBandit == null){
            onlyBandit = bandit;
        }
        return onlyBandit;
    }

    /**
     * Constructor for the Bandit class.
     * @param hitPoint the initial hit point value for the Bandit archetype.
     * @param weapon the initial weapon equipped by the Bandit archetype.
     */
    private Bandit(int hitPoint, WeaponItem weapon) {
        super("Bandit", hitPoint, weapon);
    }


}
