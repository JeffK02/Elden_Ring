package game.actors.players;

import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.weapons.Uchigatana;

/**
 * The class Samurai is a subclass of CombatArchetype representing the Samurai archetype in the game.
 */
public class Samurai extends CombatArchetype{

    private static Samurai onlySamurai = null;

    /**
     *
     * Returns the singleton instance of the Samurai archetype.
     * @return the singleton instance of the Samurai archetype.
     */
    public static Samurai getInstance(){
        Samurai samurai = new Samurai(455, new Uchigatana());
        if (onlySamurai == null){
            onlySamurai = samurai;
        }
        return onlySamurai;
    }
    /**
     * Constructor for the Samurai class.
     * @param hitPoint the initial hit point value for the Samurai archetype.
     * @param weapon the initial weapon equipped by the Samurai archetype.
     */
    private Samurai(int hitPoint, WeaponItem weapon) {
        super("Samurai", hitPoint, weapon);
    }

}
