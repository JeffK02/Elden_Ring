package game.actors.players;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;

/**
 * The abstract class CombatArchetype is the superclass for all the combat archetypes in the game.
 *
 * It defines the basic properties and functionalities for each archetype.
 */
public abstract class CombatArchetype {

    private String name;
    private static int hitPoint;
    private WeaponItem weapon;

    /**
     * Constructor for the CombatArchetype class.
     * @param hitPoint the initial hit point value for the archetype.
     * @param weapon the initial weapon equipped by the archetype.
     */
    public CombatArchetype(String name, int hitPoint, WeaponItem weapon){
        setHitPoint(hitPoint);
        setWeapon(weapon);
        this.name = name;
    }

    /**
     * Returns the hit point value of the archetype.
     * @return the hit point value of the archetype.
     */
    public static int getHitPoint() {
        return hitPoint;
    }

    /**
     * Sets the hit point value of the archetype.
     * @param hitPoint the hit point value to be set for the archetype
     */
    public void setHitPoint(int hitPoint) {
        this.hitPoint = hitPoint;
    }

    /**
     * Returns the weapon equipped by the archetype.
     * @return the weapon equipped by the archetype.
     */
    public WeaponItem getWeapon() {
        return weapon;
    }

    /**
     * Sets the weapon equipped by the archetype.
     * @param weapon the weapon to be set for the archetype.
     */
    public void setWeapon(WeaponItem weapon) {
        this.weapon = weapon;
    }

    @Override
    public String toString() {
        return name;
    }
}
