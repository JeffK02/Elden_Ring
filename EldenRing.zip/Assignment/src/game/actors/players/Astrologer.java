package game.actors.players;

import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.weapons.Grossmesser;
import game.weapons.Uchigatana;
import game.weapons.VenomousDagger;

/**
 * The Astrologer class represents a specific combat archetype called Astrologer.
 * It extends the CombatArchetype class and provides specific attributes and behavior for this archetype.
 */
public class Astrologer extends CombatArchetype{
    private static Astrologer onlyAstrologer = null;

    /**
     * Get the instance of the Astrologer archetype.
     *
     * @return the instance of the Astrologer archetype
     */
    public static Astrologer getInstance(){
        Astrologer astrologer = new Astrologer(396, new VenomousDagger());
        if (onlyAstrologer == null){
            onlyAstrologer = astrologer;
        }
        return onlyAstrologer;
    }

    /**
     * Private constructor.
     *
     * @param hitPoint the hit points of the astrologer
     * @param weapon    the weapon of the astrologer
     */
    private Astrologer(int hitPoint, WeaponItem weapon) {
        super("Astrologer", hitPoint, weapon);
    }
}
