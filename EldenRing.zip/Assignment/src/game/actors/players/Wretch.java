package game.actors.players;

import edu.monash.fit2099.engine.weapons.Weapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.weapons.Club;

/**
 * The class Wretch is a subclass of CombatArchetype representing the Wretch archetype in the game.
 */
public class Wretch extends CombatArchetype{

    private static Wretch onlyWretch = null;

    /**
     * Returns the singleton instance of the Wretch archetype.
     * @return the singleton instance of the Wretch archetype.
     */
    public static Wretch getInstance(){
        Wretch wretch = new Wretch(414, new Club());
        if (onlyWretch == null){
            onlyWretch = wretch;
        }
        return onlyWretch;
    }

    /**
     * Constructor for the Wretch class.
     * @param hitPoint the initial hit point value for the Wretch archetype.
     * @param weapon the initial weapon equipped by the Wretch archetype.
     */
    private Wretch(int hitPoint, WeaponItem weapon) {
        super("Wretch", hitPoint, weapon);
    }
}
