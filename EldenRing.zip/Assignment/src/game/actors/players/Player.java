package game.actors.players;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.displays.Menu;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import edu.monash.fit2099.engine.items.Item;
import game.item.GoldenRunes;
import game.item.GoldenSeed;
import game.item.RemembranceOfTheGrafted;
import game.managers.reset.Resettable;
import game.item.playeritems.FlaskOfCrimsonTears;
import game.utils.enums.GroundCapability;
import game.utils.enums.ItemCapability;
import game.utils.enums.Status;
import game.weapons.Grossmesser;

import java.util.ArrayList;
import java.util.List;

import static game.utils.enums.ActorRuneInteraction.COLLECTS_RUNES;

/**
 * Class representing the Player. It implements the Resettable interface.
 * It carries around a club to attack a hostile creature in the Lands Between.
 * Created by:
 * Modified by:
 *
 */
public class Player extends Actor implements Resettable {

	private CombatArchetype ca;
	private final Menu menu = new Menu();
	private static int runes;
	List<Item> inventory = getItemInventory();

	private static Location lastLocation;
	private static boolean foundSiteOfLOstGrace;
	private static Location theFirstStep;

	public Player(CombatArchetype ca) {
		super("Tarnished", '@', ca.getHitPoint());
		this.addWeaponToInventory(ca.getWeapon());
		this.addCapability(Status.HOSTILE_TO_ENEMY);
		this.addCapability(COLLECTS_RUNES);
		this.runes = 9000;
		this.ca = ca;
		addItemToInventory(new FlaskOfCrimsonTears());
		addItemToInventory(new GoldenSeed());
		addItemToInventory(new RemembranceOfTheGrafted());
	}

	@Override
	public IntrinsicWeapon getIntrinsicWeapon() {
		return new IntrinsicWeapon(11, "punch");
	}

	@Override
	public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
		System.out.println("Player Chosen Combat Archetype: " + ca);
		System.out.println("Player Current Health: " + printHp());
		System.out.println("Player Current Runes: " + getRunes());
		lastLocation = map.locationOf(this);
		if (!foundSiteOfLOstGrace){
			for(Exit exit: map.locationOf(this).getExits()){
				if(exit.getDestination().getGround().hasCapability(GroundCapability.SITE_OF_LOST_GRACE)){
					foundSiteOfLOstGrace = true;
					theFirstStep = exit.getDestination();
					break;
				}
			}
		}
		// Handle multi-turn Actions
		if (lastAction.getNextAction() != null)
			return lastAction.getNextAction();

		// return/print the console menu
		return menu.showMenu(this, actions, display);
	}



	public static int getRunes(){
		return runes;
	}

	public static void setRunes(int newRunesValue){
		runes = newRunesValue;
	}

	public static Location getTheFirstStep(){return theFirstStep;}

	public static Boolean getFoundSiteOfLostGrace(){return foundSiteOfLOstGrace;}

	public static Location getRuneDropLocation(){return lastLocation;}
	@Override
	public void reset(GameMap gameMap) {
		//reset Hp
		resetMaxHp(this.maxHitPoints);
		List<Item> removes = new ArrayList<>();
		//reset flask
		for (Item item : inventory) {
			if (item.hasCapability(ItemCapability.FLASK_OF_CRIMSON_TEARS)) {
				removes.add(item);
			}
		}
		for (Item item: removes){
			removeItemFromInventory(item);
		} addItemToInventory(new FlaskOfCrimsonTears());
	}

}
