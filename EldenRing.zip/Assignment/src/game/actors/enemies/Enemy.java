package game.actors.enemies;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.managers.reset.ResetManager;
import game.actions.AreaAttackAction;
import game.actions.AttackAction;
import game.behaviours.AttackBehaviour;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;
import game.managers.rune.RuneManager;
import game.runes.DropsRunes;
import game.utils.RandomNumberGenerator;
import game.managers.reset.Resettable;
import game.utils.enums.ActorCapability;
import game.utils.enums.EnemyType;
import game.utils.enums.Status;
import game.utils.util;

import java.util.HashMap;
import java.util.Map;

/**
 * This abstract class represents an enemy in the game. It extends the Actor class
 * and implements the DropsRunes and Resettable interfaces. Each Enemy has a type,
 * hit points, and a set of behaviours that can be performed. Behaviours are stored in
 * a HashMap, where the key is an integer representing the priority of the behaviour.
 * The constructor sets the WanderBehaviour as the default behaviour and registers the
 * Enemy object to the ResetManager. The playTurn() method selects a valid behaviour
 * based on the priority and returns the corresponding Action object. The allowableActions()
 * method returns a collection of possible Actions for the Actor, based on its capabilities
 * and the direction of other Actors. The getType() and setType() methods are used to get
 * and set the type of the Enemy. The getBehaviours() method returns the map of behaviours.
 * The reset() method is called when the game is reset.
 */
public abstract class Enemy extends Actor implements DropsRunes, Resettable {

    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**
     * Constructor.
     *
     * @param name        the name of the enemy
     * @param displayChar the character that will represent the Actor in the display
     * @param hitPoints   the enemy's starting hit points
     */
    public Enemy(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.behaviours.put(99999, new WanderBehaviour());
        ResetManager.getInstance().registerResettable(this);
        RuneManager.getInstance().addRuneDroppingActor(this);
    }

    /**
     * At each turn, select a valid action to perform.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return the valid action that can be performed in that iteration or null if no valid action is found
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        int counter = 3;
        for (Exit exit:map.locationOf(this).getExits()){
            Actor target = exit.getDestination().getActor();
            if (target!=null && target.hasCapability(Status.HOSTILE_TO_ENEMY)){
                this.getBehaviours().put(1, new AttackBehaviour(target));
                this.getBehaviours().put(2, new FollowBehaviour(target));
            } else if (target!=null && !this.findCapabilitiesByType(EnemyType.class).equals(target.findCapabilitiesByType(EnemyType.class))) {
                //attack all other actors that is not player and same type of enemy
                this.getBehaviours().put(counter, new AttackBehaviour(target));
            }
        }
        if (this.hasCapability(Status.SLEEP)){
            this.removeCapability(Status.SLEEP);
            System.out.println(name + " is sleeping peacefully!");
            return new DoNothingAction();
        }
        for (Behaviour behaviour : behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if(action != null)
                return action;
        }
        return new DoNothingAction();
    }

    /**
     * The enemy can be attacked by any actor that has the HOSTILE_TO_ENEMY capability
     *
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            actions.add(new AttackAction(this, direction));
            if(otherActor.getWeaponInventory().size()>0){
                for(WeaponItem weapon: otherActor.getWeaponInventory()){
                    actions.add(new AttackAction(this, direction, weapon));
                    if (weapon.getSkill(otherActor) != null){
                        actions.add(weapon.getSkill(otherActor));
                    }
                    //For skills that target enemy
                    if (weapon.getSkill(this, direction).getClass() != DoNothingAction.class){
                        actions.add(weapon.getSkill(this, direction));
                    }
                }
            }
            // HINT 1: The AttackAction above allows you to attack the enemy with your intrinsic weapon.
            // HINT 1: How would you attack the enemy with a weapon?
        }
        //Remove action if surroundings does not have other actor
        if(util.nearbyActor(otherActor, map).size() == 1){
            ActionList modified_actions = new ActionList();
            for(Action action: actions){
                if(!action.getClass().equals(AreaAttackAction.class)){
                    modified_actions.add(action);
                }
            }
            actions = modified_actions;
        }
        return actions;
    }

    public Map<Integer, Behaviour> getBehaviours() {
        return behaviours;
    }

    @Override
    public void reset(GameMap map) {
        map.removeActor(this);
    }

    public int generateRuneValue(){
        return 0; //placeholder default value
    };
}
