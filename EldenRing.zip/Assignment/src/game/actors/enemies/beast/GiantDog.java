package game.actors.enemies.beast;

import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.actors.enemies.Enemy;
import game.runes.DropsRunes;
import game.utils.RandomNumberGenerator;
import game.utils.enums.AttackCapability;

/**
 * The GiantDog class represents a type of Beast enemy in the game that drops runes when defeated.
 * It extends the Beast class and implements the DropsRunes interface.
 * It has a name, display character, hit points, and capabilities. It also has a specific range of rune values
 * it can drop when defeated.
 */
public class GiantDog extends Beast implements DropsRunes {
    /**
     * The low range of rune values that can be dropped by this enemy.
     */
    public final int RUNES_LOW = 313;
    /**
     * The high range of rune values that can be dropped by this enemy.
     */
    public final int RUNES_HIGH = 1808;

    /**
     * Constructor for the GiantDog class.
     * It sets the name, display character, and hit points of the enemy.
     * It also adds the AttackCapability.AREA_ATTACK capability to the enemy.
     */
    public GiantDog() {
        super("Giant Dog", 'G', 693);
        addCapability(AttackCapability.AREA_ATTACK);
    }

    /**
     * Returns the intrinsic weapon of the enemy, which is a melee slam attack that deals 314 base damage.
     * @return an IntrinsicWeapon object representing the enemy's melee attack.
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(314, "slams", 90);
    }

    /**
     *
     Generates a random rune value within the specified range of this enemy.
     @return an integer representing the value of the rune dropped by the enemy.
     */
    @Override
    public int generateRuneValue(){
        return RandomNumberGenerator.getRandomInt(RUNES_LOW, RUNES_HIGH);
    }
}
