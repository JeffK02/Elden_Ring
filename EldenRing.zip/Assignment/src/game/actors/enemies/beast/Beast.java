package game.actors.enemies.beast;

import game.actors.enemies.Enemy;
import game.utils.enums.EnemyType;

/**
 * The abstract class Beast extends Enemy class and represents a type of Enemy.
 *
 * It sets the type of enemy to BEAST and adds the capability of BEAST to the enemy.
 */
public abstract class Beast extends Enemy {
    /**
     * Constructor for the Beast class.
     * @param name the name of the beast
     * @param displayChar the character that represents the beast on the map
     * @param hitPoints the number of hit points the beast has
     */
    public Beast(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        addCapability(EnemyType.BEAST);
    }

}
