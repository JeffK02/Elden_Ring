package game.actors.enemies.stormveilcastle;

import game.actors.enemies.Enemy;
import game.utils.enums.EnemyType;

/**
 * The StormVeilCastleEnemy class represents an enemy in the Storm Veil Castle.
 * It is an abstract class that extends the Enemy class and provides common functionality for enemies in the castle.
 */
public abstract class StormVeilCastleEnemy extends Enemy {

    /**
     * Constructor.
     *
     * @param name        the name of the enemy
     * @param displayChar the character used to display the enemy
     * @param hitPoints   the hit points of the enemy
     */
    public StormVeilCastleEnemy(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        addCapability(EnemyType.STORM_VEIL_CASTLE);
    }
}
