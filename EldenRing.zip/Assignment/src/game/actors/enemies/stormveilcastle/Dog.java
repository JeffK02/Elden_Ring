package game.actors.enemies.stormveilcastle;

import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.utils.RandomNumberGenerator;

/**
 * The Dog class represents a dog enemy in the Storm Veil Castle.
 * It extends the StormVeilCastleEnemy class and provides specific attributes and behavior for dogs.
 */
public class Dog extends StormVeilCastleEnemy{
    public final int RUNES_LOW = 52;
    public final int RUNES_HIGH = 1390;

    /**
     * Constructor.
     */
    public Dog() {
        super("Dog", 'a', 104);
    }

    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(101, "bites", 93);
    }

    @Override
    public int generateRuneValue(){
        return RandomNumberGenerator.getRandomInt(RUNES_LOW, RUNES_HIGH);
    }
}
