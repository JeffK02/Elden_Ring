package game.actors.enemies.stormveilcastle;

import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.utils.RandomNumberGenerator;

/**
 * The GodrickSoldier class represents a soldier enemy in the Storm Veil Castle.
 * It extends the StormVeilCastleEnemy class and provides specific attributes and behavior for Godrick's soldiers.
 */
public class GodrickSoldier extends StormVeilCastleEnemy{
    public final int RUNES_LOW = 38;
    public final int RUNES_HIGH = 70;

    /**
     * Constructor.
     */
    public GodrickSoldier() {
        super("Godrick Soldier", 'p', 198);
    }

    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(123, "bonks", 95);
    }

    @Override
    public int generateRuneValue(){
        return RandomNumberGenerator.getRandomInt(RUNES_LOW, RUNES_HIGH);
    }
}
