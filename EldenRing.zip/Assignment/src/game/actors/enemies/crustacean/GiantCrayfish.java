package game.actors.enemies.crustacean;

import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.runes.DropsRunes;
import game.utils.RandomNumberGenerator;
import game.utils.enums.AttackCapability;

/**
 * A class representing a Giant Crayfish enemy in the game.
 *
 * Giant Crayfishes are a type of Crustacean and can drop runes.
 */
public class GiantCrayfish extends Crustacean implements DropsRunes {

    public final int RUNES_LOW = 500;
    public final int RUNES_HIGH = 2374;

    /**
     * Constructor of a new Giant Crayfish object.
     * Giant Crayfishes are a type of Crustacean and have an intrinsic weapon that crushes the player.
     */
    public GiantCrayfish() {
        super("Giant Crayfish", 'R', 4803);
        addCapability(AttackCapability.AREA_ATTACK);
    }

    /**
     * Returns the intrinsic weapon of the Giant Crayfish.
     * @return the intrinsic weapon of the Giant Crayfish.
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(527, "crushes", 100);
    }

    /**
     * Generates a random rune value between the specified low and high values.
     * @return a random rune value between the specified low and high values.
     */
    @Override
    public int generateRuneValue(){
        return RandomNumberGenerator.getRandomInt(RUNES_LOW, RUNES_HIGH);
    }
}
