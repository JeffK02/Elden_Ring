package game.actors.enemies.crustacean;

import game.actors.enemies.Enemy;
import game.item.GoldenSeed;
import game.utils.enums.AttackCapability;
import game.utils.enums.EnemyType;

/**
 * A class representing a generic crustacean enemy in the game.
 *
 * Crustaceans are enemies that are capable of area attacks.
 */
public abstract class Crustacean extends Enemy {
    /**
     * Constructs a new Crustacean object.
     * @param name the name of the Crustacean.
     * @param displayChar the character that represents the Crustacean in the game.
     * @param hitPoints the amount of hit points that the Crustacean has.
     */
    public Crustacean(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        addCapability(AttackCapability.AREA_ATTACK);
        addCapability(EnemyType.CRUSTACEAN);
        addItemToInventory(new GoldenSeed());
    }

}
