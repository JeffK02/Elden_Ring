package game.actors.enemies.crustacean;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AreaAttackAction;
import game.actions.AttackAction;
import game.actors.enemies.crustacean.Crustacean;
import game.behaviours.Behaviour;
import game.behaviours.WanderBehaviour;
import game.utils.enums.AttackCapability;
import game.runes.DropsRunes;
import game.utils.RandomNumberGenerator;
import game.utils.enums.Status;
import game.utils.util;

import java.util.HashMap;
import java.util.Map;

/**
 * A class representing a Giant Crab enemy in the game.
 *
 * Giant Crabs are a type of Crustacean and can drop runes.
 */
public class GiantCrab extends Crustacean implements DropsRunes {
    public final int RUNES_LOW = 318;
    public final int RUNES_HIGH = 4961;
    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**
     * Constructor of a new Giant Crab object.
     * Giant Crabs are a type of Crustacean and have an intrinsic weapon that slams the player.
     */
    public GiantCrab() {
        super("Giant Crab", 'c', 407);
        addCapability(AttackCapability.AREA_ATTACK);
    }

    /**
     * Returns the intrinsic weapon of the Giant Crab.
     * @return the intrinsic weapon of the Giant Crab.
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        return new IntrinsicWeapon(208, "slams", 90);
    }

    /**
     * Generates a random rune value between the specified low and high values.
     * @return a random rune value between the specified low and high values.
     */
    @Override
    public int generateRuneValue(){
        return RandomNumberGenerator.getRandomInt(RUNES_LOW, RUNES_HIGH);
    }
}