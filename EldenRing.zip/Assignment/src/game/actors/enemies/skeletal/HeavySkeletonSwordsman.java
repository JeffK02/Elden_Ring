package game.actors.enemies.skeletal;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AreaAttackAction;
import game.actions.AttackAction;
import game.behaviours.Behaviour;
import game.behaviours.WanderBehaviour;
import game.utils.enums.Status;
import game.utils.util;
import game.weapons.Grossmesser;

import java.util.HashMap;
import java.util.Map;
/**
 * A type of Skeletal enemy that is a swordsman, possessing a grossmesser weapon.
 */
public class HeavySkeletonSwordsman extends Skeletal{
    /**
     * Creates a new HeavySkeletonSwordsman enemy object.
     */
    public HeavySkeletonSwordsman() {
        super("Heavy Skeletal Swordsman", 'q', 153);
        addWeaponToInventory(new Grossmesser());
    }
}

