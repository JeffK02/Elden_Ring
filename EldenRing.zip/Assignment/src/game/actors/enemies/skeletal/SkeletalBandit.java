package game.actors.enemies.skeletal;

import game.weapons.Scimitar;
/**
 * A type of Skeletal enemy that is a bandit, possessing a scimitar weapon.
 */
public class SkeletalBandit extends Skeletal{
    /**
     * Creates a new SkeletalBandit enemy object.
     */
    public SkeletalBandit() {
        super("Skeletal Bandit", 'b', 184);
        addWeaponToInventory(new Scimitar());
    }
}
