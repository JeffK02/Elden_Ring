package game.actors.enemies.skeletal;

import game.actors.enemies.Enemy;
import game.utils.enums.EnemyAbility;
import game.utils.enums.EnemyType;
import game.utils.enums.Status;
/**
 * A type of enemy that is skeletal in nature, possessing the ability to form piles of bones.
 */
public abstract class Skeletal extends Enemy {
    /**
     * Creates a new Skeletal enemy object.
     * @param name the name of the Skeletal enemy
     * @param displayChar the character used to display the Skeletal enemy
     * @param hitPoints the initial hit points of the Skeletal enemy
     */
    public Skeletal(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        addCapability(EnemyAbility.PILE_OF_BONES);
        addCapability(EnemyType.SKELETAL);
    }


}
