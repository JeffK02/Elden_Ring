package game.actors.enemies.skeletal;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.ReviveAction;
import game.utils.RandomNumberGenerator;
import game.utils.enums.EnemyAbility;
/**
 * A type of Skeletal enemy that forms a pile of bones and revives into a HeavySkeletonSwordsman after not being attacked three times.
 */
public class PileOfBones extends Skeletal {
    private int counter = 1;
    private final int RUNES_LOW = 35;
    private final int RUNES_HIGH = 892;
    /**
     * Creates a new PileOfBones enemy object.
     */
    public PileOfBones() {
        super("Pile Of Bones", 'X', 1);
        //No behaviours or capabilities
        removeCapability(EnemyAbility.PILE_OF_BONES);
        getBehaviours().clear();
    }

    /**
     * At each turn, select a valid action to perform.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return the valid action that can be performed in that iteration or null if no valid action is found
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        //if not attack by others for three times
        if (counter < 3){
            counter++;
        }
        else if (counter == 3) {
            HeavySkeletonSwordsman h1 = new HeavySkeletonSwordsman();
            return new ReviveAction(h1);
        }
        return new DoNothingAction();
    }

    @Override
    public int generateRuneValue(){
        return RandomNumberGenerator.getRandomInt(RUNES_LOW, RUNES_HIGH);
    }
}
