package game.actors.astrology;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actors.players.CombatArchetype;
import game.behaviours.Behaviour;
import game.behaviours.WanderBehaviour;

import java.util.HashMap;
import java.util.Map;

/**
 * The AstrologyActor class is an abstract class that represents an astrology actor in the game.
 * It extends the Actor class and provides additional functionality specific to astrology actors.
 */
public abstract class AstrologyActor extends Actor {

    /**
     * The behaviours of the astrology actor
     */
    private Map<Integer, Behaviour> behaviours = new HashMap<>();

    /**
     * The combat archetype of the astrology actor
     */
    private CombatArchetype ca;

    /**
     * Constructor.
     *
     * @param name        the name of the astrology actor
     * @param displayChar the display character of the astrology actor
     * @param ca          the combat archetype of the astrology actor
     */
    public AstrologyActor(String name, char displayChar, CombatArchetype ca) {
        super(name, displayChar, ca.getHitPoint());
        this.ca = ca;
        addWeaponToInventory(ca.getWeapon());
        this.behaviours.put(99999, new WanderBehaviour());
    }

    /**
     * Gets the behaviours of the astrology actor.
     *
     * @return the behaviours of the astrology actor
     */
    public Map<Integer, Behaviour> getBehaviours() {
        return behaviours;
    }

    /**
     * Gets the combat archetype of the astrology actor.
     *
     * @return the combat archetype of the astrology actor
     */
    public CombatArchetype getCa() {
        return ca;
    }
}
