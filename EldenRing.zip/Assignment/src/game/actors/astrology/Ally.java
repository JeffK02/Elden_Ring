package game.actors.astrology;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actors.players.CombatArchetype;
import game.behaviours.AttackBehaviour;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.utils.enums.ActorCapability;
import game.utils.enums.Status;
import game.utils.util;

/**
 * The Ally class represents an ally astrology actor in the game.
 * It extends the AstrologyActor class and provides additional functionality specific to allies.
 */
public class Ally extends AstrologyActor {

    /**
     * Constructor.
     */
    public Ally() {
        super("Ally", 'A', util.randomCA());
        addCapability(ActorCapability.ALLY);
    }

    /**
     * Overrides the playTurn method from the Actor class to define the ally's behavior during its turn.
     *
     * @param actions    the list of available actions
     * @param lastAction the last action performed
     * @param map        the game map
     * @param display    the display to show the game
     * @return the action to be performed by the ally
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        int counter = 3;
        for (Exit exit:map.locationOf(this).getExits()){
            Actor target = exit.getDestination().getActor();
            if (target!=null && !target.hasCapability(Status.HOSTILE_TO_ENEMY) && !target.hasCapability(ActorCapability.ALLY)){
                this.getBehaviours().put(counter, new AttackBehaviour(target));
            }
        }

        for (Behaviour behaviour : this.getBehaviours().values()) {
            Action action = behaviour.getAction(this, map);
            if(action != null)
                return action;
        }
        return new DoNothingAction();
    }
}
