package game.actors.astrology;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.AreaAttackAction;
import game.actions.AttackAction;
import game.behaviours.AttackBehaviour;
import game.behaviours.Behaviour;
import game.behaviours.FollowBehaviour;
import game.managers.rune.RuneManager;
import game.runes.DropsRunes;
import game.utils.RandomNumberGenerator;
import game.utils.enums.ActorCapability;
import game.utils.enums.Status;
import game.utils.util;

/**
 * The Invader class represents an invader astrology actor in the game.
 * It extends the AstrologyActor class and provides additional functionality specific to invaders.
 * It also implements the DropsRunes interface to allow the invader to drop runes upon defeat.
 */
public class Invader extends AstrologyActor implements DropsRunes {
    public final int RUNES_LOW = 1358;
    public final int RUNES_HIGH = 5578;

    /**
     * Constructor.
     */
    public Invader() {
        super("Invader", 'ඞ', util.randomCA());
        addCapability(ActorCapability.INVADER);
        RuneManager.getInstance().addRuneDroppingActor(this);
    }

    /**
     * Overrides the playTurn method from the AstrologyActor class to define the invader's behavior during its turn.
     *
     * @param actions    the list of available actions
     * @param lastAction the last action performed
     * @param map        the game map
     * @param display    the display to show the game
     * @return the action to be performed by the invader
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        int counter = 3;
        for (Exit exit:map.locationOf(this).getExits()){
            Actor target = exit.getDestination().getActor();
            if (target!=null && target.hasCapability(Status.HOSTILE_TO_ENEMY)){
                this.getBehaviours().put(1, new AttackBehaviour(target));
                this.getBehaviours().put(2, new FollowBehaviour(target));
            } else if (target!=null && !target.hasCapability(ActorCapability.INVADER)) {
                //attack all other actors that is not player
                this.getBehaviours().put(counter, new AttackBehaviour(target));
            }
        }

        if (this.hasCapability(Status.SLEEP)){
            this.removeCapability(Status.SLEEP);
            return new DoNothingAction();
        }

        for (Behaviour behaviour : this.getBehaviours().values()) {
            Action action = behaviour.getAction(this, map);
            if(action != null)
                return action;
        }
        return new DoNothingAction();
    }

    /**
     * Overrides the allowableActions method from the AstrologyActor class to define the actions that can be performed by the invader towards other actors.
     *
     * @param otherActor the other actor
     * @param direction  the direction towards the other actor
     * @param map        the game map
     * @return the list of allowable actions towards the other actor
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            actions.add(new AttackAction(this, direction));
            if(otherActor.getWeaponInventory().size()>0){
                for(WeaponItem weapon: otherActor.getWeaponInventory()){
                    actions.add(new AttackAction(this, direction, weapon));
                    if (weapon.getSkill(otherActor) != null){
                        actions.add(weapon.getSkill(otherActor));
                    }
                    //For skills that target enemy
                    if (weapon.getSkill(this, direction).getClass() != DoNothingAction.class){
                        actions.add(weapon.getSkill(this, direction));
                    }
                }
            }
            // HINT 1: The AttackAction above allows you to attack the enemy with your intrinsic weapon.
            // HINT 1: How would you attack the enemy with a weapon?
        }
        //Remove action if surroundings does not have other actor
        if(util.nearbyActor(otherActor, map).size() == 1){
            ActionList modified_actions = new ActionList();
            for(Action action: actions){
                if(!action.getClass().equals(AreaAttackAction.class)){
                    modified_actions.add(action);
                }
            }
            actions = modified_actions;
        }
        return actions;
    }

    @Override
    public int generateRuneValue(){
        return RandomNumberGenerator.getRandomInt(RUNES_LOW, RUNES_HIGH);
    }
}
