package game.actors.merchants;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.shoppingActions.ShoppingAction;
import game.item.Purchasable;
import game.weapons.Club;
import game.weapons.GreatKnife;
import game.weapons.Uchigatana;
import game.weapons.VenomousDagger;

import java.util.ArrayList;

/**
 * MerchantKale class.
 * This class represents the merchant that can be found in Limgrave. Can buy and sell weapons to this actor.
 */
public class MerchantKale extends Merchant{
    private static ArrayList<Purchasable> sellingWares = new ArrayList<Purchasable>();

    /**
     * MerchantKale constructor.
     * Initialises the MerchantKale class.
     */
    public MerchantKale() {
        super("Merchant Kale", 'B');
        addWares(new Uchigatana());
        addWares(new GreatKnife());
        addWares(new Club());
        addWares(new VenomousDagger());
    }

    /**
     * allowableActions method.
     * MerchantKale allows actors to shop with them.
     * @param otherActor the Actor that might be performing attack
     * @param direction  String representing the direction of the other Actor
     * @param map        current GameMap
     * @return
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        // use other actor to determine proximity
        actions.add(new ShoppingAction(this));
        return actions;
    }

    /**
     * Adds a purchasable item to the selling offerings of MerchantKale
     * @param purchasableItem item to be offered by Kale
     */
    public void addWares(Purchasable purchasableItem) {
        sellingWares.add(purchasableItem);
    }

    /**
     * Returns a list of all items that can be bought from Kale.
     * @return arraylist of purchasables. All items that can be bought from Kale
     */
    public static ArrayList<Purchasable> listWares() {
        // creating defensive copy
        ArrayList<Purchasable> res = new ArrayList<Purchasable>();
        for (int i = 0; i < sellingWares.size(); i++) {
            res.add(sellingWares.get(i));
        }
        return res;
    }
}