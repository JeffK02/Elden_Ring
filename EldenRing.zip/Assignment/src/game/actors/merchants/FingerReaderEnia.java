package game.actors.merchants;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import game.actions.TradingAction;
import game.actions.shoppingActions.ShoppingAction;
import game.item.Tradable;
import game.managers.shop.TradingManager;
import game.weapons.AxeOfGodrick;
import game.weapons.GraftedDragon;

import java.util.ArrayList;

/**
 * The FingerReaderEnia class represents a merchant named Finger Reader Enia.
 * It extends the Merchant class and provides specific attributes and behavior for this merchant.
 */
public class FingerReaderEnia extends Merchant{
    private static ArrayList<WeaponItem> tradingWares = new ArrayList<WeaponItem>();

    /**
     * Constructor.
     */
    public FingerReaderEnia(){
        super("Finger Reader Enia", 'E');
        addWares(new AxeOfGodrick());
        addWares(new GraftedDragon());
    }

    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        // use other actor to determine proximity
        actions.add(new TradingAction(this));
        return actions;
    }

    /**
     * Add a tradable weapon to the merchant's wares.
     *
     * @param tradableWeapon the tradable weapon to add
     */
    public void addWares(WeaponItem tradableWeapon) {
        tradingWares.add(tradableWeapon);
    }

    /**
     * Get a list of the merchant's trading wares.
     *
     * @return a list of tradable weapon items
     */
    public static ArrayList<WeaponItem> listWares() {
        // creating defensive copy
        ArrayList<WeaponItem> res = new ArrayList<WeaponItem>();
        for (int i = 0; i < tradingWares.size(); i++) {
            res.add(tradingWares.get(i));
        }
        return res;
    }
}
