package game.actors.merchants;
import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import game.actions.shoppingActions.ShoppingAction;
import game.item.Purchasable;


import java.util.ArrayList;

/**
 * Merchant class. NPCs that can sell the player offerings.
 * Created by: James
 * @author James
 * Modified by:
 */
public abstract class Merchant extends Actor {
    /**
     * Merchant Health. Not relevant as merchant should not be attacked due to being on Floor type ground.
     */
    private static final int MERCHANT_HEALTH = 9999;

    /**
     * Merchant constructor.
     * @param name name of merchant
     * @param displayChar character used to display in overworld
     */
    public Merchant(String name, char displayChar) {
        super(name, displayChar, MERCHANT_HEALTH);
    }

    /**
     * playTurn method for Merchant.
     * Merchant child classes can implement required actions (ex. trading or shopping)
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn. Can do interesting things in conjunction with Action.getNextAction()
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        return new DoNothingAction();
    }

}
